package com.example.tfg_josemanuelmendezrodriguez;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Clase que permite crear un adaptador para los discos de la pantalla principal
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class AdaptadorRecyclerView extends RecyclerView.Adapter<AdaptadorRecyclerView.ViewHolder> {

    List<ListaDiscos> listaDiscos; /** Variable que almacena los discos*/
    LayoutInflater inflater; /** Variable utilizada para inflar el adaptador*/
    Context contexto; /** Variable que representa el contexto de la aplicación*/

    /**
     * Constructor de la clase con dos parámetros.
     * @param listaDiscos
     * @param contexto
     */
    public AdaptadorRecyclerView(List<ListaDiscos> listaDiscos, Context contexto){

        this.listaDiscos = listaDiscos;
        this.contexto = contexto;
        this.inflater = LayoutInflater.from(contexto);
    }

    /**
     * Método que crea y devuelve un objeto ViewHolder
     * @param parent The ViewGroup into which the new View will be added after it is bound to
     *               an adapter position.
     * @param viewType The view type of the new View.
     *
     * @return
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.estilo_lista_discos, null);
        return new ViewHolder(view);
    }

    /**
     * Método usado para enlazar elementos a la vista correspondiente del ViewHolder
     * @param holder The ViewHolder which should be updated to represent the contents of the
     *        item at the given position in the data set.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.bind(listaDiscos.get(position));
    }

    /**
     * Método que devuelve cuantos elementos hay en la lista de los discos
     * @return
     */
    @Override
    public int getItemCount() {
        return listaDiscos.size();
    }

    /**
     * Esta subclase representa al objeto ViewHolder mencionado anteriormente
     */
    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView disco;/** Variable que representa el nombre del disco*/
        TextView artista;/** Variable que representa el artista del disco*/
        /**
         * Constructor de la clase al cual se le pasa un parámetro
         * @param itemView
         */
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            disco = itemView.findViewById(R.id.textView_Disco_Estilo);
            artista = itemView.findViewById(R.id.textView_Artista_Estilo);
        }

        /**
         * Método que enlaza el nombre del disco y del artista con los de un valor de la lista de los discos
         * @param valor
         */
        void bind(ListaDiscos valor){

            disco.setText(valor.getDisco());
            artista.setText(valor.getArtista());
        }


    }
}