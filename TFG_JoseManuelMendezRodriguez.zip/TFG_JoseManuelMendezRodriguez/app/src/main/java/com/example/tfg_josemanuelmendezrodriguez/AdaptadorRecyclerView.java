package com.example.tfg_josemanuelmendezrodriguez;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadorRecyclerView extends RecyclerView.Adapter<AdaptadorRecyclerView.ViewHolder> {


    List<ListaDiscos> listaDiscos;
    LayoutInflater inflater;
    Context contexto;

    public AdaptadorRecyclerView(List<ListaDiscos> listaDiscos, Context contexto){

        this.listaDiscos = listaDiscos;
        this.contexto = contexto;
        this.inflater = LayoutInflater.from(contexto);
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.estilo_lista_discos, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.bind(listaDiscos.get(position));
    }

    @Override
    public int getItemCount() {
        return listaDiscos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView disco;
        TextView artista;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            disco = itemView.findViewById(R.id.textView_Disco_Estilo);
            artista = itemView.findViewById(R.id.textView_Artista_Estilo);
        }

        void bind(ListaDiscos valor){

            disco.setText(valor.getDisco());
            artista.setText(valor.getArtista());
        }


    }
}