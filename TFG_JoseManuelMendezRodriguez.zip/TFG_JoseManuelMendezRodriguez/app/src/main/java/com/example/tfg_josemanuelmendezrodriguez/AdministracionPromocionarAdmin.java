package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.android.material.textfield.TextInputLayout;

/**
 * Clase asociada a la pantalla en la que un usuario puede obtener privilegios de administrador
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class AdministracionPromocionarAdmin extends AppCompatActivity {

    ImageButton imgBtn_VolverAtras_AdministracionPromocionarAdmin; /** Image button que devolverá al usuario a la pantalla anterior*/
    Button btn_Promocionar_AdministracionPromocionarAdmin; /** Botón que pulsará el usuario para introducir el código de administrador*/
    TextInputLayout textInput_CodigoAdmin_AdministracionPromocionarAdmin; /** Text input layout que utilizará el usuario para escribir el código del administrador*/
    EditText ed_CodigoAdmin_AdministracionPromocionarAdmin; /** Edit text que contiene texto informativo*/
    Toolbar toolbar_Promocionar_Admin; /** Variable que representa a la toolbar*/
    /**
     * Método onCreate de la clase
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     *
     */
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administracion_promocionar_admin);

        /** Asocio las variables con sus id*/
        imgBtn_VolverAtras_AdministracionPromocionarAdmin = findViewById(R.id.imgBtn_Flecha_Toolbar_Administracion_PromocionarAdmin);
        textInput_CodigoAdmin_AdministracionPromocionarAdmin = findViewById(R.id.textInput_CodigoAdmin_AdministracionPromocionarAdmin);
        ed_CodigoAdmin_AdministracionPromocionarAdmin = findViewById(R.id.textEdit_CodigoAdmin_AdministracionPromocionarAdmin);
        btn_Promocionar_AdministracionPromocionarAdmin = findViewById(R.id.btn_Promocionar_AdministracionPromocionarAdmin);
        toolbar_Promocionar_Admin = findViewById(R.id.toolbar_Administracion_PromocionarAdmin);
        setSupportActionBar(toolbar_Promocionar_Admin);

        /** Creo un objeto modelo y recibo los datos del intent*/
        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");

        /**
         * Escuchador del imageButton para volver a la pantalla anterior
         */
        imgBtn_VolverAtras_AdministracionPromocionarAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(AdministracionPromocionarAdmin.this, Perfil.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();

            }
        });

        /**
         * Escuchador del botón para introducir las credenciales y poder obtener privilegios de administrador
         */
        btn_Promocionar_AdministracionPromocionarAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(ed_CodigoAdmin_AdministracionPromocionarAdmin.getText().toString().equals("DmC4dbfz")){

                    textInput_CodigoAdmin_AdministracionPromocionarAdmin.setHelperText("");

                    modelo.promocionarAdmin(AdministracionPromocionarAdmin.this, id_Usuario);

                    AlertDialog.Builder alerta = new AlertDialog.Builder(AdministracionPromocionarAdmin.this);
                    alerta.setTitle("Exito");
                    alerta.setMessage("La cuenta ahora tiene privilegios de administrador");
                    alerta.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Intent intent = new Intent(AdministracionPromocionarAdmin.this, Perfil.class);
                            intent.putExtra("id", id_Usuario);
                            startActivity(intent);
                            finish();

                        }
                    });

                    AlertDialog dialogo = alerta.create();
                    dialogo.show();

                }else{

                    textInput_CodigoAdmin_AdministracionPromocionarAdmin.setHelperText("El código introducido no es correcto");
                    textInput_CodigoAdmin_AdministracionPromocionarAdmin.setHelperTextColor(getResources().getColorStateList(R.color.red));
                }

            }
        });

        /**
         * Método que pregunta al usuario si quiere salir de la aplicación al pulsar el botón "Atras" del teléfono
         */
        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(AdministracionPromocionarAdmin.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });

    }
}