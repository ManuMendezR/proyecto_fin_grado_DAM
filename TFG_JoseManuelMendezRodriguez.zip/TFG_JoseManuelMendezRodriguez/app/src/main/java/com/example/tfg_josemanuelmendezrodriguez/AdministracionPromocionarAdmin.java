package com.example.tfg_josemanuelmendezrodriguez;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.android.material.textfield.TextInputLayout;

public class AdministracionPromocionarAdmin extends AppCompatActivity {

    ImageButton imgBtn_VolverAtras_AdministracionPromocionarAdmin;
    Button btn_Promocionar_AdministracionPromocionarAdmin;
    TextInputLayout textInput_CodigoAdmin_AdministracionPromocionarAdmin;
    EditText ed_CodigoAdmin_AdministracionPromocionarAdmin;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administracion_promocionar_admin);

        imgBtn_VolverAtras_AdministracionPromocionarAdmin = findViewById(R.id.imgBtn_FlechaVolver_AdministracionPromocionarAdmin);
        textInput_CodigoAdmin_AdministracionPromocionarAdmin = findViewById(R.id.textInput_CodigoAdmin_AdministracionPromocionarAdmin);
        ed_CodigoAdmin_AdministracionPromocionarAdmin = findViewById(R.id.textEdit_CodigoAdmin_AdministracionPromocionarAdmin);
        btn_Promocionar_AdministracionPromocionarAdmin = findViewById(R.id.btn_Promocionar_AdministracionPromocionarAdmin);

        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");

        imgBtn_VolverAtras_AdministracionPromocionarAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(AdministracionPromocionarAdmin.this, Perfil.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();

            }
        });

        btn_Promocionar_AdministracionPromocionarAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(ed_CodigoAdmin_AdministracionPromocionarAdmin.getText().toString().equals("DmC4dbfz")){

                    textInput_CodigoAdmin_AdministracionPromocionarAdmin.setHelperText("");

                    modelo.promocionarAdmin(AdministracionPromocionarAdmin.this, id_Usuario);

                    AlertDialog.Builder alerta = new AlertDialog.Builder(AdministracionPromocionarAdmin.this);
                    alerta.setTitle("Exito");
                    alerta.setMessage("La cuenta ahora tiene privilegios de administrador");
                    alerta.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Intent intent = new Intent(AdministracionPromocionarAdmin.this, Perfil.class);
                            intent.putExtra("id", id_Usuario);
                            startActivity(intent);
                            finish();

                        }
                    });

                    AlertDialog dialogo = alerta.create();
                    dialogo.show();

                }else{

                    textInput_CodigoAdmin_AdministracionPromocionarAdmin.setHelperText("El código introducido no es correcto");
                    textInput_CodigoAdmin_AdministracionPromocionarAdmin.setHelperTextColor(getResources().getColorStateList(R.color.red));
                }

            }
        });

    }
}