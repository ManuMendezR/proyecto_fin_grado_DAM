package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public class AnadirDiscos extends AppCompatActivity {

    ImageButton imgBtn_Flecha_Toolbar_AnadirDiscos;
    TextInputLayout inputLayout_NombreDisco_AnadirDiscos;
    TextInputLayout inputLayout_Artista_AnadirDiscos;
    TextInputLayout inputLayout_Genero_AnadirDiscos;
    TextInputLayout inputLayout_NumCanciones_AnadirDiscos;
    TextInputLayout inputLayout_Precio_AnadirDiscos;
    TextInputLayout inputLayout_Stock_AnadirDiscos;
    EditText ed_NombreDisco_AnadirDiscos;
    EditText ed_Artista_AnadirDiscos;
    EditText ed_Genero_AnadirDiscos;
    EditText ed_NumCanciones_AnadirDiscos;
    EditText ed_Precio_AnadirDiscos;
    EditText ed_Stock_AnadirDiscos;
    Button btn_Anadir_AnadirDiscos;
    Toolbar toolbar_AnadirDiscos;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anadir_discos);

        imgBtn_Flecha_Toolbar_AnadirDiscos = findViewById(R.id.imgBtn_Flecha_Toolbar_Anadir_Disco);
        inputLayout_NombreDisco_AnadirDiscos = findViewById(R.id.textInput_NombreDisco_AnadirDiscos);
        inputLayout_Artista_AnadirDiscos = findViewById(R.id.textInput_Artista_AnadirDiscos);
        inputLayout_Genero_AnadirDiscos = findViewById(R.id.textInput_Genero_AnadirDiscos);
        inputLayout_NumCanciones_AnadirDiscos = findViewById(R.id.textInput_NumCanciones_AnadirDiscos);
        inputLayout_Precio_AnadirDiscos = findViewById(R.id.textInput_Precio_AnadirDiscos);
        inputLayout_Stock_AnadirDiscos = findViewById(R.id.textInput_Stock_AnadirDiscos);
        ed_NombreDisco_AnadirDiscos = findViewById(R.id.textEdit_NombreDisco_AnadirDiscos);
        ed_Artista_AnadirDiscos = findViewById(R.id.textEdit_Artista_AnadirDiscos);
        ed_Genero_AnadirDiscos = findViewById(R.id.textEdit_Genero_AnadirDiscos);
        ed_NumCanciones_AnadirDiscos = findViewById(R.id.textEdit_NumCanciones_AnadirDiscos);
        ed_Precio_AnadirDiscos = findViewById(R.id.textEdit_Precio_AnadirDiscos);
        ed_Stock_AnadirDiscos = findViewById(R.id.textEdit_Stock_AnadirDiscos);
        btn_Anadir_AnadirDiscos = findViewById(R.id.btn_Anadir_AnadirDiscos);
        toolbar_AnadirDiscos = findViewById(R.id.toolbar_Anadir_Disco);

        setSupportActionBar(toolbar_AnadirDiscos);

        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");

        imgBtn_Flecha_Toolbar_AnadirDiscos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(AnadirDiscos.this, PantallaPrincipal.class);
                intent.putExtra("id",id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        btn_Anadir_AnadirDiscos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!ed_NombreDisco_AnadirDiscos.getText().toString().trim().isEmpty() && !ed_Artista_AnadirDiscos.getText().toString().trim().isEmpty() && !ed_Genero_AnadirDiscos.getText().toString().trim().isEmpty()
                && !ed_NumCanciones_AnadirDiscos.getText().toString().trim().isEmpty() && !ed_Precio_AnadirDiscos.toString().trim().isEmpty() && !ed_Precio_AnadirDiscos.getText().toString().trim().isEmpty() && !ed_Stock_AnadirDiscos.getText().toString().trim().isEmpty()){

                    if(ed_NombreDisco_AnadirDiscos.getText().toString().trim().length()>1 && ed_NombreDisco_AnadirDiscos.getText().toString().trim().length()<25){

                        inputLayout_NombreDisco_AnadirDiscos.setHelperText("");

                        if(ed_Artista_AnadirDiscos.getText().toString().trim().length()>3 && ed_Artista_AnadirDiscos.getText().toString().trim().length()<25){

                            inputLayout_Artista_AnadirDiscos.setHelperText("");

                            if(ed_Genero_AnadirDiscos.getText().toString().trim().length()>3 && ed_Genero_AnadirDiscos.getText().toString().trim().length()<25){

                                inputLayout_Genero_AnadirDiscos.setHelperText("");

                                if(modelo.getIDDisco(AnadirDiscos.this, ed_NombreDisco_AnadirDiscos.getText().toString().trim()) == -1){

                                    Disco disco = new Disco();
                                    disco.setNombreDisco(ed_NombreDisco_AnadirDiscos.getText().toString().trim());
                                    disco.setArtista(ed_Artista_AnadirDiscos.getText().toString().trim());
                                    disco.setGenero(ed_Genero_AnadirDiscos.getText().toString().trim());
                                    disco.setNum_canciones(Integer.valueOf(ed_NumCanciones_AnadirDiscos.getText().toString().trim()));
                                    disco.setPrecio(Double.valueOf(ed_Precio_AnadirDiscos.getText().toString().trim()));
                                    disco.setStock(Integer.valueOf(ed_Stock_AnadirDiscos.getText().toString().trim()));
                                    modelo.insertaDisco(AnadirDiscos.this, disco);

                                    AlertDialog.Builder alerta = new AlertDialog.Builder(AnadirDiscos.this);
                                    alerta.setTitle("Exito");
                                    alerta.setMessage("El disco se ha añadido correctamente");
                                    alerta.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {

                                            Intent intent = new Intent(AnadirDiscos.this, PantallaPrincipal.class);
                                            intent.putExtra("id", id_Usuario);
                                            startActivity(intent);
                                            finish();

                                        }
                                    });

                                    AlertDialog dialogo = alerta.create();
                                    dialogo.show();

                                }else{

                                    inputLayout_NombreDisco_AnadirDiscos.setHelperText("Ya existe un disco con ese nombre");
                                    inputLayout_NombreDisco_AnadirDiscos.setHelperTextColor(getResources().getColorStateList(R.color.red));
                                }

                            }else{

                                inputLayout_Genero_AnadirDiscos.setHelperText("El genero debe tener entre 4 y 25 caracteres");
                                inputLayout_Genero_AnadirDiscos.setHelperTextColor(getResources().getColorStateList(R.color.red));
                            }

                        }else{

                            inputLayout_Artista_AnadirDiscos.setHelperText("El nombre del artista debe tener entre 4 y 25 caraccteres");
                            inputLayout_Artista_AnadirDiscos.setHelperTextColor(getResources().getColorStateList(R.color.red));
                        }


                    }else{

                        inputLayout_NombreDisco_AnadirDiscos.setHelperText("EL nombre debe tener entre 2 y 25 caracteres");
                        inputLayout_NombreDisco_AnadirDiscos.setHelperTextColor(getResources().getColorStateList(R.color.red));
                    }

                }else{

                    Toast.makeText(AnadirDiscos.this, "Por favor, rellene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(AnadirDiscos.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }
}