package com.example.tfg_josemanuelmendezrodriguez;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

//Esta clase se va a encargar de hacer la conexión con la base de datos
public class ConexionSQLite extends SQLiteOpenHelper {

    //Esta sentencia creará la base de datos necesaria
    String table_usuarios = "CREATE TABLE usuarios(id INTEGER PRIMARY KEY AUTOINCREMENT, nombre_usuario VARCHAR(50) NOT NULL, email VARCHAR(50) NOT NULL, contrasena VARCHAR(50) NOT NULL, tipo VARCHAR(50) NOT NULL)";
    String table_discos = "CREATE TABLE discos(id INTEGER PRIMARY KEY AUTOINCREMENT, nombre_disco VARCHAR(50) NOT NULL, artista VARCHAR(50) NOT NULL, genero VARCHAR(50) NOT NULL, num_canciones INTEGER NOT NULL, precio REAL NOT NULL,  stock INTEGER NOT NULL, puntuacion_total REAL NOT NULL)";
    String table_valoraciones = "CREATE TABLE valoraciones(id INTEGER PRIMARY KEY AUTOINCREMENT, id_Usuario INTEGER, id_Disco INTEGER, puntuacion REAL, FOREIGN KEY (id_Usuario) REFERENCES usuarios(id) ON DELETE SET NULL, FOREIGN KEY (id_Disco) REFERENCES discos(id) ON DELETE SET NULL)";
    String table_ventas = "CREATE TABLE ventas(id INTEGER PRIMARY KEY AUTOINCREMENT, id_Usuario VARCHAR(50), id_Disco VARCHAR(50) NOT NULL, FOREIGN KEY (id_Usuario) REFERENCES usuarios(id) ON DELETE SET NULL, FOREIGN KEY (id_Disco) REFERENCES discos(id) ON DELETE SET NULL)";


    //Constructor de la clase
    public ConexionSQLite(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    //Este método ejecuta la sentencia previamente creada
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL(table_usuarios);
        sqLiteDatabase.execSQL(table_discos);
        sqLiteDatabase.execSQL(table_valoraciones);
        sqLiteDatabase.execSQL(table_ventas);
        sqLiteDatabase.execSQL("PRAGMA foreign_keys = ON;");

    }
    // Este método se utiliza para realizar cambios en la estructura de la base de datos cuando hay una actualización de la versión de la aplicación
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}