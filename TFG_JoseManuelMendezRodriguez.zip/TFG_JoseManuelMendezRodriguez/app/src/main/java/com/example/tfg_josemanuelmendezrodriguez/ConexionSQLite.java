package com.example.tfg_josemanuelmendezrodriguez;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

/**
 * Clase encargada de realizar la conexión con la base de datos
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class ConexionSQLite extends SQLiteOpenHelper {

    /** Sentencia sql que creará la tabla de los usuarios*/
    String table_usuarios = "CREATE TABLE usuarios(id INTEGER PRIMARY KEY AUTOINCREMENT, nombre_usuario VARCHAR(50) NOT NULL, email VARCHAR(50) NOT NULL, contrasena VARCHAR(50) NOT NULL, tipo VARCHAR(50) NOT NULL)";
    /** Sentencia sql que creará la tabla de los discos*/
    String table_discos = "CREATE TABLE discos(id INTEGER PRIMARY KEY AUTOINCREMENT, nombre_disco VARCHAR(50) NOT NULL, artista VARCHAR(50) NOT NULL, genero VARCHAR(50) NOT NULL, num_canciones INTEGER NOT NULL, precio REAL NOT NULL,  stock INTEGER NOT NULL, puntuacion_total REAL NOT NULL)";
    /** Sentencia sql que creará la tabla de las valoraciones*/
    String table_valoraciones = "CREATE TABLE valoraciones(id INTEGER PRIMARY KEY AUTOINCREMENT, id_Usuario INTEGER, id_Disco INTEGER, puntuacion REAL, FOREIGN KEY (id_Usuario) REFERENCES usuarios(id) ON DELETE SET NULL, FOREIGN KEY (id_Disco) REFERENCES discos(id) ON DELETE SET NULL)";
    /** Sentencia sql que creará la tabla de las ventas*/
    String table_ventas = "CREATE TABLE ventas(id INTEGER PRIMARY KEY AUTOINCREMENT, id_Usuario VARCHAR(50), id_Disco VARCHAR(50) NOT NULL, fecha DATE, FOREIGN KEY (id_Usuario) REFERENCES usuarios(id) ON DELETE SET NULL, FOREIGN KEY (id_Disco) REFERENCES discos(id) ON DELETE SET NULL)";


    /**
     * Constructor de la clase al que se le pasan 4 parámetros
     * @param context
     * @param name
     * @param factory
     * @param version
     */
    public ConexionSQLite(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    /**
     * Método onCreate de la clase que ejecutará las sentencias sql para crear las tablas
     * @param sqLiteDatabase The database.
     */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL(table_usuarios);
        sqLiteDatabase.execSQL(table_discos);
        sqLiteDatabase.execSQL(table_valoraciones);
        sqLiteDatabase.execSQL(table_ventas);
        sqLiteDatabase.execSQL("PRAGMA foreign_keys = ON;");

    }

    /**
     * Método utilizado para realizar cambios en la estructura de la base de datos cuando hay una actualización de la versión de la aplicación
     * @param sqLiteDatabase The database.
     * @param i The old database version.
     * @param i1 The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}