package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class DetallesDisco extends AppCompatActivity {

    ImageButton imgBtn_Flecha_Toolbar_DetallesDisco;
    TextView textView_NombreDisco_DetallesDisco;
    TextView textView_Artista_DetallesDisco;
    TextView textView_Genero_DetallesDisco;
    TextView textView_NumCanciones_DetallesDisco;
    TextView textView_Precio_DetallesDisco;
    TextView textView_Stock_DetallesDisco;
    TextView textView_PuntuacionTotal_DetallesDisco;
    RatingBar ratingBar_Puntuacion_DetallesDisco;
    Toolbar toolbar_Detalles_Disco;
    Button btn_Comprar_DetallesDisco;
    Button btn_Valorar_DetallesDisco;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_disco);

        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");
        String id_Disco =  extras.getString("id_disco");
        String nombre_disco = extras.getString("nombre_disco");
        String artista = extras.getString("artista");

        imgBtn_Flecha_Toolbar_DetallesDisco = findViewById(R.id.imgBtn_Flecha_Toolbar_Detalles_Disco);
        textView_NombreDisco_DetallesDisco = findViewById(R.id.textView_NombreDisco_DetallesDisco);
        textView_Artista_DetallesDisco = findViewById(R.id.textView_Artista_DetallesDisco);
        textView_Genero_DetallesDisco = findViewById(R.id.textView_Genero_DetallesDisco);
        textView_NumCanciones_DetallesDisco = findViewById(R.id.textView_NumCanciones_DetallesDisco);
        textView_Precio_DetallesDisco = findViewById(R.id.textView_Precio_DetallesDisco);
        textView_Stock_DetallesDisco = findViewById(R.id.textView_Stock_DetallesDisco);
        ratingBar_Puntuacion_DetallesDisco = findViewById(R.id.ratingBar_Puntuacion_DetallesDisco);
        toolbar_Detalles_Disco = findViewById(R.id.toolbar_Detalles_Disco);
        textView_PuntuacionTotal_DetallesDisco = findViewById(R.id.textView_PuntuacionTotal_DetallesDisco);
        btn_Comprar_DetallesDisco = findViewById(R.id.btn_Comprar_DetallesDisco);
        btn_Valorar_DetallesDisco = findViewById(R.id.btn_Valorar_DetallesDisco);

        setSupportActionBar(toolbar_Detalles_Disco);


        textView_NombreDisco_DetallesDisco.setText("Nombre: "+nombre_disco);
        textView_Artista_DetallesDisco.setText("Artista: "+artista);
        textView_Genero_DetallesDisco.setText("Genero: "+modelo.getGeneroDisco(DetallesDisco.this, nombre_disco));
        textView_NumCanciones_DetallesDisco.setText("Canciones: "+modelo.getNumCancionesDisco(DetallesDisco.this, nombre_disco));
        textView_Precio_DetallesDisco.setText("Precio: "+modelo.getPrecioDisco(DetallesDisco.this, nombre_disco)+" €");
        textView_Stock_DetallesDisco.setText("Quedan "+modelo.getStockDisco(DetallesDisco.this, nombre_disco)+" en stock");
        textView_PuntuacionTotal_DetallesDisco.setText("Valoracion usuarios: "+Math.floor(Double.valueOf(modelo.getPuntuacionTotalDisco(DetallesDisco.this, nombre_disco)) * 100) / 100+"/5 estrellas");

        imgBtn_Flecha_Toolbar_DetallesDisco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DetallesDisco.this, PantallaPrincipal.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        btn_Valorar_DetallesDisco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(modelo.comprobarUsuarioValidacion(DetallesDisco.this, id_Usuario, id_Disco) == -1){

                    Valoracion valoracion = new Valoracion();
                    valoracion.setId_Disco(id_Disco);
                    valoracion.setId_Usuario(id_Usuario);
                    valoracion.setPuntuacion(Double.valueOf(ratingBar_Puntuacion_DetallesDisco.getRating()));

                    modelo.insertaValoracion(DetallesDisco.this,valoracion);

                    int count = modelo.getCountPuntuaciones(DetallesDisco.this, id_Disco);
                    double sum = modelo.getSumaPuntuacion(DetallesDisco.this, id_Disco);
                    double resultado = sum/count;

                    modelo.actualizarPuntuacionTotal(DetallesDisco.this, id_Disco, resultado);
                    textView_PuntuacionTotal_DetallesDisco.setText("Valoracion usuarios: "+Math.floor(Double.valueOf(modelo.getPuntuacionTotalDisco(DetallesDisco.this, nombre_disco)) * 100) / 100+"/5 estrellas");

                }else{

                    Toast.makeText(DetallesDisco.this, "No mas", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_Comprar_DetallesDisco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int stock = Integer.valueOf(modelo.getStockDisco(DetallesDisco.this, nombre_disco));

                if(stock > 0){

                    AlertDialog.Builder alerta = new AlertDialog.Builder(DetallesDisco.this);
                    alerta.setTitle("Comprar");
                    alerta.setMessage("¿Quiere comprar este disco?");
                    alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Venta venta = new Venta();
                            venta.setId_Disco(id_Disco);
                            venta.setId_Usuario(id_Usuario);
                            modelo.insertaVenta(DetallesDisco.this, venta);
                            modelo.actualizarStock(DetallesDisco.this, id_Disco,stock-1);

                            Intent intent = new Intent(DetallesDisco.this, ProcesandoCompra.class);
                            intent.putExtra("id", id_Usuario);
                            startActivity(intent);

                        }
                    });
                    alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog dialogo = alerta.create();
                    dialogo.show();

                }
            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(DetallesDisco.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }
}