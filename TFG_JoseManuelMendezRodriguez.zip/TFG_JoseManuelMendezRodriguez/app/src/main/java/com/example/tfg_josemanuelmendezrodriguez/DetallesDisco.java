package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * Clase asociada a la pantalla que muestra los detalles de un disco y permite valorarlo y comprarlo
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class DetallesDisco extends AppCompatActivity {

    ImageButton imgBtn_Flecha_Toolbar_DetallesDisco; /** ImageButton que permite al usuario volver a la pantalla anterior*/
    TextView textView_NombreDisco_DetallesDisco; /** TextView con la información del nombre del disco*/
    TextView textView_Artista_DetallesDisco; /** TextView con la información del artista del disco*/
    TextView textView_Genero_DetallesDisco; /** TextView con la información del genero del disco*/
    TextView textView_NumCanciones_DetallesDisco; /** TextView con la información del número de canciones del disco*/
    TextView textView_Precio_DetallesDisco; /** TextView con la información del precio del disco*/
    TextView textView_Stock_DetallesDisco; /** TextView con la información del stock del disco*/
    TextView textView_PuntuacionTotal_DetallesDisco; /** TextView con la información de la puntuación total del disco*/
    RatingBar ratingBar_Puntuacion_DetallesDisco; /** RatingBar que permite establecer la puntuación que el usuario quiere dar al disco*/
    Toolbar toolbar_Detalles_Disco; /** Variable asociada a la toolbar*/
    Button btn_Comprar_DetallesDisco; /** Botón que permite al usuario comprar un disco*/
    Button btn_Valorar_DetallesDisco; /** Botón que permite al usuario valorar un disco*/
    /**
     * Método onCreate de la clase
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     *
     */
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_disco);

        /** Asocio las variables con sus respectivas id*/
        imgBtn_Flecha_Toolbar_DetallesDisco = findViewById(R.id.imgBtn_Flecha_Toolbar_Detalles_Disco);
        textView_NombreDisco_DetallesDisco = findViewById(R.id.textView_NombreDisco_DetallesDisco);
        textView_Artista_DetallesDisco = findViewById(R.id.textView_Artista_DetallesDisco);
        textView_Genero_DetallesDisco = findViewById(R.id.textView_Genero_DetallesDisco);
        textView_NumCanciones_DetallesDisco = findViewById(R.id.textView_NumCanciones_DetallesDisco);
        textView_Precio_DetallesDisco = findViewById(R.id.textView_Precio_DetallesDisco);
        textView_Stock_DetallesDisco = findViewById(R.id.textView_Stock_DetallesDisco);
        ratingBar_Puntuacion_DetallesDisco = findViewById(R.id.ratingBar_Puntuacion_DetallesDisco);
        toolbar_Detalles_Disco = findViewById(R.id.toolbar_Detalles_Disco);
        textView_PuntuacionTotal_DetallesDisco = findViewById(R.id.textView_PuntuacionTotal_DetallesDisco);
        btn_Comprar_DetallesDisco = findViewById(R.id.btn_Comprar_DetallesDisco);
        btn_Valorar_DetallesDisco = findViewById(R.id.btn_Valorar_DetallesDisco);
        setSupportActionBar(toolbar_Detalles_Disco);

        /** Creo un objeto modelo y recibo los datos del intent*/
        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");
        String id_Disco =  extras.getString("id_disco");
        String nombre_disco = extras.getString("nombre_disco");
        String artista = extras.getString("artista");

        /** Reparto la información del disco entre los distintos textView*/
        textView_NombreDisco_DetallesDisco.setText("Nombre: "+nombre_disco);
        textView_Artista_DetallesDisco.setText("Artista: "+artista);
        textView_Genero_DetallesDisco.setText("Genero: "+modelo.getGeneroDisco(DetallesDisco.this, nombre_disco));
        textView_NumCanciones_DetallesDisco.setText("Canciones: "+modelo.getNumCancionesDisco(DetallesDisco.this, nombre_disco));
        textView_Precio_DetallesDisco.setText("Precio: "+modelo.getPrecioDisco(DetallesDisco.this, nombre_disco)+" €");
        textView_Stock_DetallesDisco.setText("Quedan "+modelo.getStockDisco(DetallesDisco.this, nombre_disco)+" en stock");
        textView_PuntuacionTotal_DetallesDisco.setText("Valoracion usuarios: "+Math.floor(Double.valueOf(modelo.getPuntuacionTotalDisco(DetallesDisco.this, nombre_disco)) * 10) / 10+"/5 estrellas");

        /**
         * Escuchador del ImageButton que permite al usuario volver a la pantalla anterior
         */
        imgBtn_Flecha_Toolbar_DetallesDisco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DetallesDisco.this, PantallaPrincipal.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        /**
         * Escuchador del botón "Valorar" que permite al usuario valorar el disco
         */
        btn_Valorar_DetallesDisco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(modelo.comprobarUsuarioValidacion(DetallesDisco.this, id_Usuario, id_Disco) == -1){

                    if(ratingBar_Puntuacion_DetallesDisco.getRating()>0){


                        Valoracion valoracion = new Valoracion();
                        valoracion.setId_Disco(id_Disco);
                        valoracion.setId_Usuario(id_Usuario);
                        valoracion.setPuntuacion(Double.valueOf(ratingBar_Puntuacion_DetallesDisco.getRating()));

                        modelo.insertaValoracion(DetallesDisco.this,valoracion);

                        int count = modelo.getCountPuntuaciones(DetallesDisco.this, id_Disco);
                        double sum = modelo.getSumaPuntuacion(DetallesDisco.this, id_Disco);
                        double resultado = sum/count;

                        modelo.actualizarPuntuacionTotal(DetallesDisco.this, id_Disco, resultado);
                        textView_PuntuacionTotal_DetallesDisco.setText("Valoracion usuarios: "+Math.floor(Double.valueOf(modelo.getPuntuacionTotalDisco(DetallesDisco.this, nombre_disco)) * 10) / 10+"/5 estrellas");
                        Toast.makeText(DetallesDisco.this, "¡Gracias por tu valoración!", Toast.LENGTH_SHORT).show();

                    }else{

                        Toast.makeText(DetallesDisco.this, "Por favor, seleccione una cantidad de estrellas", Toast.LENGTH_SHORT).show();
                    }

                }else{

                    Toast.makeText(DetallesDisco.this, "Ya has valorado este disco", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /**
         * Escuchador del botón "Comprar" que permite al usuario comprar un disco
         */
        btn_Comprar_DetallesDisco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Date fechaActual = new Date();

                // Formatear la fecha en el formato deseado
                SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String fechaFormateada = formatoFecha.format(fechaActual);

                int stock = Integer.valueOf(modelo.getStockDisco(DetallesDisco.this, nombre_disco));

                if(stock > 0){

                    AlertDialog.Builder alerta = new AlertDialog.Builder(DetallesDisco.this);
                    alerta.setTitle("Comprar");
                    alerta.setMessage("¿Quiere comprar este disco?");
                    alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Venta venta = new Venta();
                            venta.setId_Disco(id_Disco);
                            venta.setId_Usuario(id_Usuario);
                            venta.setFecha(fechaFormateada); //Falta resetear la base de datos
                            modelo.insertaVenta(DetallesDisco.this, venta);
                            modelo.actualizarStock(DetallesDisco.this, id_Disco,stock-1);

                            Intent intent = new Intent(DetallesDisco.this, ProcesandoCompra.class);
                            intent.putExtra("id", id_Usuario);
                            startActivity(intent);
                            finish();

                        }
                    });
                    alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog dialogo = alerta.create();
                    dialogo.show();

                }else{

                    Toast.makeText(DetallesDisco.this, "Actualmente no hay stock de este disco", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /**
         * Método que pregunta al usuario si quiere salir de la aplicación al pulsar el botón "Atras" del teléfono
         */
        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(DetallesDisco.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }
}