package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;

public class DetallesDisco extends AppCompatActivity {

    ImageButton imgBtn_FlechaVolver_DetallesDisco;
    TextView textView_NombreDisco_DetallesDisco;
    TextView textView_Artista_DetallesDisco;
    TextView textView_Genero_DetallesDisco;
    TextView textView_NumCanciones_DetallesDisco;
    TextView textView_Precio_DetallesDisco;
    TextView textView_Stock_DetallesDisco;
    RatingBar ratingBar_Puntuacion_DetallesDisco;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_disco);

        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");
        String id_Disco =  extras.getString("id_disco");
        String nombre_disco = extras.getString("nombre_disco");
        String artista = extras.getString("artista");

        imgBtn_FlechaVolver_DetallesDisco = findViewById(R.id.imgBtn_FlechaVolver_DetallesDisco);
        textView_NombreDisco_DetallesDisco = findViewById(R.id.textView_NombreDisco_DetallesDisco);
        textView_Artista_DetallesDisco = findViewById(R.id.textView_Artista_DetallesDisco);
        textView_Genero_DetallesDisco = findViewById(R.id.textView_Genero_DetallesDisco);
        textView_NumCanciones_DetallesDisco = findViewById(R.id.textView_NumCanciones_DetallesDisco);
        textView_Precio_DetallesDisco = findViewById(R.id.textView_Precio_DetallesDisco);
        textView_Stock_DetallesDisco = findViewById(R.id.textView_Stock_DetallesDisco);
        ratingBar_Puntuacion_DetallesDisco = findViewById(R.id.ratingBar_Puntuacion_DetallesDisco);

        textView_NombreDisco_DetallesDisco.setText("Nombre: "+nombre_disco);
        textView_Artista_DetallesDisco.setText("Artista: "+artista);
        textView_Genero_DetallesDisco.setText("Genero: "+modelo.getGeneroDisco(DetallesDisco.this, nombre_disco));
        textView_NumCanciones_DetallesDisco.setText("Canciones: "+modelo.getNumCancionesDisco(DetallesDisco.this, nombre_disco));
        textView_Precio_DetallesDisco.setText("Precio: "+modelo.getPrecioDisco(DetallesDisco.this, nombre_disco)+" €");
        textView_Stock_DetallesDisco.setText("Quedan "+modelo.getStockDisco(DetallesDisco.this, nombre_disco)+" en stock");

        imgBtn_FlechaVolver_DetallesDisco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DetallesDisco.this, PantallaPrincipal.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(DetallesDisco.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }
}