package com.example.tfg_josemanuelmendezrodriguez;

/**
 * Clase que representa un objeto de tipo Disco
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class Disco {

    private String nombreDisco; /** Variable que representa el nombre del disco*/
    private String artista; /** Variable que representa el artista del disco*/
    private String genero; /** Variable que representa el genero del disco*/
    private int num_canciones; /** Variable que representa el número de canciones del disco*/
    private double precio; /** Variable que representa el precio del disco*/
    private double puntuacion; /** Variable que representa la puntuación del disco*/
    private int stock; /** Variable que representa el stock del disco*/

    /**
     * Método que obtiene el nombre de un disco
     * @return
     */
    public String getNombreDisco() {
        return nombreDisco;
    }

    /**
     * Método que establece el nombre de un disco
     * @param nombreDisco
     */
    public void setNombreDisco(String nombreDisco) {
        this.nombreDisco = nombreDisco;
    }

    /**
     * Método que obtiene el artista de un disco
     * @return
     */
    public String getArtista() {
        return artista;
    }

    /**
     * Método que establece el artista de un disco
     * @param artista
     */
    public void setArtista(String artista) {
        this.artista = artista;
    }

    /**
     * Método que obtiene el género de un disco
     * @return
     */
    public String getGenero() {
        return genero;
    }

    /**
     * Método que establece el género de un disco
     * @param genero
     */
    public void setGenero(String genero) {
        this.genero = genero;
    }

    /**
     * Método que obtiene el número de canciones de un disco
     * @return
     */
    public int getNum_canciones() {
        return num_canciones;
    }

    /**
     * Método que establece el número de canciones de un disco
     * @param num_canciones
     */
    public void setNum_canciones(int num_canciones) {
        this.num_canciones = num_canciones;
    }

    /**
     * Método que obtiene el precio de un disco
     * @return
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * Método que establece el precio de un disco
     * @param precio
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * Método que obtiene el stock de un disco
     * @return
     */
    public int getStock() {
        return stock;
    }

    /**
     * Método que establece el stock de un disco
     * @param stock
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     * Método que obtiene la puntuación de un disco
     * @return
     */
    public double getPuntuacion() {
        return puntuacion;
    }

    /**
     * Método que establece la puntuación de un disco
     * @param puntuacion
     */
    public void setPuntuacion(double puntuacion) {
        this.puntuacion = puntuacion;
    }
}
