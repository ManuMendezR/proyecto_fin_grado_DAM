package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public class EditarDiscos extends AppCompatActivity {

    ImageButton imgBtn_Flecha_Toolbar_EditarDiscos;
    TextInputLayout inputLayout_NombreDisco_EditarDiscos;
    TextInputLayout inputLayout_Artista_EditarDiscos;
    TextInputLayout inputLayout_Genero_EditarDiscos;
    TextInputLayout inputLayout_NumCanciones_EditarDiscos;
    TextInputLayout inputLayout_Precio_EditarDiscos;
    TextInputLayout inputLayout_Stock_EditarDiscos;
    EditText ed_NombreDisco_EditarDiscos;
    EditText ed_Artista_EditarDiscos;
    EditText ed_Genero_EditarDiscos;
    EditText ed_NumCanciones_EditarDiscos;
    EditText ed_Precio_EditarDiscos;
    EditText ed_Stock_EditarDiscos;
    Button btn_Editar_EditarDiscos;
    Toolbar toolbar_EditarDiscos;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_disco);

        imgBtn_Flecha_Toolbar_EditarDiscos = findViewById(R.id.imgBtn_Flecha_Toolbar_Editar_Disco);
        inputLayout_NombreDisco_EditarDiscos = findViewById(R.id.textInput_NombreDisco_EditarDiscos);
        inputLayout_Artista_EditarDiscos = findViewById(R.id.textInput_Artista_EditarDiscos);
        inputLayout_Genero_EditarDiscos = findViewById(R.id.textInput_Genero_EditarDiscos);
        inputLayout_NumCanciones_EditarDiscos = findViewById(R.id.textInput_NumCanciones_EditarDiscos);
        inputLayout_Precio_EditarDiscos = findViewById(R.id.textInput_Precio_EditarDiscos);
        inputLayout_Stock_EditarDiscos = findViewById(R.id.textInput_Stock_EditarDiscos);
        ed_NombreDisco_EditarDiscos = findViewById(R.id.textEdit_NombreDisco_EditarDiscos);
        ed_Artista_EditarDiscos = findViewById(R.id.textEdit_Artista_EditarDiscos);
        ed_Genero_EditarDiscos = findViewById(R.id.textEdit_Genero_EditarDiscos);
        ed_NumCanciones_EditarDiscos = findViewById(R.id.textEdit_NumCanciones_EditarDiscos);
        ed_Precio_EditarDiscos = findViewById(R.id.textEdit_Precio_EditarDiscos);
        ed_Stock_EditarDiscos = findViewById(R.id.textEdit_Stock_EditarDiscos);
        btn_Editar_EditarDiscos = findViewById(R.id.btn_Editar_EditarDiscos);
        toolbar_EditarDiscos = findViewById(R.id.toolbar_Editar_Disco);

        setSupportActionBar(toolbar_EditarDiscos);

        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");
        String id_Disco =  extras.getString("id_disco");
        String nombre_disco = extras.getString("nombre_disco");
        String artista = extras.getString("artista");

        ed_NombreDisco_EditarDiscos.setText(nombre_disco);
        ed_Artista_EditarDiscos.setText(artista);
        ed_Genero_EditarDiscos.setText(modelo.getGeneroDisco(EditarDiscos.this, nombre_disco));
        ed_NumCanciones_EditarDiscos.setText(modelo.getNumCancionesDisco(EditarDiscos.this, nombre_disco));
        ed_Precio_EditarDiscos.setText(modelo.getPrecioDisco(EditarDiscos.this, nombre_disco));
        ed_Stock_EditarDiscos.setText(modelo.getStockDisco(EditarDiscos.this, nombre_disco));
        String nombre_Inicial = ed_NombreDisco_EditarDiscos.getText().toString();

        imgBtn_Flecha_Toolbar_EditarDiscos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(EditarDiscos.this, ListaEditarDiscos.class);
                intent.putExtra("id",id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        btn_Editar_EditarDiscos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!ed_NombreDisco_EditarDiscos.getText().toString().isEmpty() && !ed_Artista_EditarDiscos.getText().toString().isEmpty() && !ed_Genero_EditarDiscos.getText().toString().isEmpty()
                && !ed_NumCanciones_EditarDiscos.getText().toString().isEmpty() && !ed_Precio_EditarDiscos.getText().toString().isEmpty() && !ed_Stock_EditarDiscos.getText().toString().isEmpty()){

                    if(ed_NombreDisco_EditarDiscos.getText().toString().trim().length()>1 && ed_NombreDisco_EditarDiscos.getText().toString().trim().length()<15){

                        inputLayout_NombreDisco_EditarDiscos.setHelperText("");

                        if(ed_Artista_EditarDiscos.getText().toString().trim().length()>=3 && ed_Artista_EditarDiscos.getText().toString().trim().length()<15){

                            inputLayout_Artista_EditarDiscos.setHelperText("");

                            if(ed_Genero_EditarDiscos.getText().toString().trim().length()>=3 && ed_Genero_EditarDiscos.getText().toString().trim().length()<15){

                                inputLayout_Genero_EditarDiscos.setHelperText("");

                                if(modelo.getIDDisco(EditarDiscos.this, ed_NombreDisco_EditarDiscos.getText().toString().trim()) == -1 || ed_NombreDisco_EditarDiscos.getText().toString().equals(nombre_Inicial) ){

                                    Disco disco = new Disco();
                                    disco.setNombreDisco(ed_NombreDisco_EditarDiscos.getText().toString().trim());
                                    disco.setArtista(ed_Artista_EditarDiscos.getText().toString().trim());
                                    disco.setGenero(ed_Genero_EditarDiscos.getText().toString().trim());
                                    disco.setNum_canciones(Integer.valueOf(ed_NumCanciones_EditarDiscos.getText().toString().trim()));
                                    disco.setPrecio(Double.valueOf(ed_Precio_EditarDiscos.getText().toString().trim()));
                                    disco.setStock(Integer.valueOf(ed_Stock_EditarDiscos.getText().toString().trim()));
                                    modelo.actualizarDisco(EditarDiscos.this, disco, id_Disco);

                                    AlertDialog.Builder alerta = new AlertDialog.Builder(EditarDiscos.this);
                                    alerta.setTitle("Exito");
                                    alerta.setMessage("El disco se ha actualizado correctamente");
                                    alerta.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {

                                            Intent intent = new Intent(EditarDiscos.this, PantallaPrincipal.class);
                                            intent.putExtra("id", id_Usuario);
                                            startActivity(intent);
                                            finish();

                                        }
                                    });

                                    AlertDialog dialogo = alerta.create();
                                    dialogo.show();

                                }else{

                                    inputLayout_NombreDisco_EditarDiscos.setHelperText("Ya existe un disco con ese nombre");
                                    inputLayout_NombreDisco_EditarDiscos.setHelperTextColor(getResources().getColorStateList(R.color.red));

                                    inputLayout_Genero_EditarDiscos.setHelperText("");
                                    inputLayout_Artista_EditarDiscos.setHelperText("");
                                }


                            }else{

                                inputLayout_Genero_EditarDiscos.setHelperText("El genero debe tener entre 3 y 15 caracteres");
                                inputLayout_Genero_EditarDiscos.setHelperTextColor(getResources().getColorStateList(R.color.red));

                                inputLayout_NombreDisco_EditarDiscos.setHelperText("");
                                inputLayout_Artista_EditarDiscos.setHelperText("");
                            }


                            }else{

                            inputLayout_Artista_EditarDiscos.setHelperText("El nombre del artista debe tener entre 3 y 15 caraccteres");
                            inputLayout_Artista_EditarDiscos.setHelperTextColor(getResources().getColorStateList(R.color.red));

                            inputLayout_NombreDisco_EditarDiscos.setHelperText("");
                            inputLayout_Genero_EditarDiscos.setHelperText("");
                        }


                        }else{

                        inputLayout_NombreDisco_EditarDiscos.setHelperText("El nombre debe tener entre 2 y 15 caracteres");
                        inputLayout_NombreDisco_EditarDiscos.setHelperTextColor(getResources().getColorStateList(R.color.red));

                        inputLayout_Artista_EditarDiscos.setHelperText("");
                        inputLayout_Genero_EditarDiscos.setHelperText("");
                    }

                    }else{

                    Toast.makeText(EditarDiscos.this, "Por favor, rellene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(EditarDiscos.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }
}