package com.example.tfg_josemanuelmendezrodriguez;

import android.graphics.Rect;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class EspaciadoRecyclerView extends RecyclerView.ItemDecoration{

    private final int espacioVertical;

    public EspaciadoRecyclerView(int espacioVertical) {
        this.espacioVertical = espacioVertical;
    }

    @Override
    public void getItemOffsets(@NonNull Rect outRect, int itemPosition, @NonNull RecyclerView parent) {
        outRect.bottom = espacioVertical;
    }
}
