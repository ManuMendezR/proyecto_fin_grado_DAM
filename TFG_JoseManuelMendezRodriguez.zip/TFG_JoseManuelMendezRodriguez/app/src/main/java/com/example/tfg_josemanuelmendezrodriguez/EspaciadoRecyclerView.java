package com.example.tfg_josemanuelmendezrodriguez;

import android.graphics.Rect;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Clase que añadirá un pequeño espaciado entre los distintos discos en la pantalla principal
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class EspaciadoRecyclerView extends RecyclerView.ItemDecoration{

    private final int espacioVertical; /** Variable que almacenará el valor del espaciado*/

    /**
     * Constructor de la clase al que se le pasa un parámetro
     * @param espacioVertical
     */
    public EspaciadoRecyclerView(int espacioVertical) {
        this.espacioVertical = espacioVertical;
    }

    /**
     * Método que establece el espaacio entre los distintos elementos
     * @param outRect
     * @param itemPosition
     * @param parent
     */
    @Override
    public void getItemOffsets(@NonNull Rect outRect, int itemPosition, @NonNull RecyclerView parent) {
        outRect.bottom = espacioVertical;
    }
}
