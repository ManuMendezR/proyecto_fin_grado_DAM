package com.example.tfg_josemanuelmendezrodriguez;

public class ListaDiscos {

    String disco;
    String artista;

    public ListaDiscos(String disco, String artista){

        this.disco = disco;
        this.artista = artista;
    }

    public String getDisco() {
        return disco;
    }

    public void setDisco(String disco) {
        this.disco = disco;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }
}
