package com.example.tfg_josemanuelmendezrodriguez;

/**
 * Clase que representa un objeto de tipo ListaDiscos
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class ListaDiscos {

    String disco; /** Variable que representa el nombre del disco*/
    String artista; /** Variable que representa el artista del disco*/

    /**
     * Constructor de la clase al que se le pasan dos parámetros
     * @param disco
     * @param artista
     */
    public ListaDiscos(String disco, String artista){

        this.disco = disco;
        this.artista = artista;
    }

    /**
     * Método que obtiene el nombre del disco
     * @return
     */
    public String getDisco() {
        return disco;
    }

    /**
     * Método que establece el nombre del disco
     * @param disco
     */
    public void setDisco(String disco) {
        this.disco = disco;
    }

    /**
     * Método que obtiene el artista del disco
     * @return
     */
    public String getArtista() {
        return artista;
    }

    /**
     * Método que establece el artista del disco
     * @param artista
     */
    public void setArtista(String artista) {
        this.artista = artista;
    }
}
