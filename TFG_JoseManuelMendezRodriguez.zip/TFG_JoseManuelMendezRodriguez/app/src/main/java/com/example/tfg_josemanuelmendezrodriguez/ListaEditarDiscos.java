package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.List;

public class ListaEditarDiscos extends AppCompatActivity {

    ImageButton imgBtn_FlechaVolver_ListaEditarDiscos;
    RecyclerView recyclerView_ListaDiscos_ListaEditarDiscos;
    List<ListaDiscos> listaDiscos_ListaEditarDiscos;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_editar_discos);

        imgBtn_FlechaVolver_ListaEditarDiscos = findViewById(R.id.imgBtn_FlechaVolver_ListaEditarDiscos);
        recyclerView_ListaDiscos_ListaEditarDiscos = findViewById(R.id.recyclerView_ListaDiscos_ListaEditarDiscos);

        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");

        imgBtn_FlechaVolver_ListaEditarDiscos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ListaEditarDiscos.this, PantallaPrincipal.class);
                intent.putExtra("id",id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        listaDiscos_ListaEditarDiscos = modelo.getListaDiscos(ListaEditarDiscos.this);
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL);
        recyclerView_ListaDiscos_ListaEditarDiscos.setLayoutManager(staggeredGridLayoutManager);
        EspaciadoRecyclerView erv = new EspaciadoRecyclerView(10);
        recyclerView_ListaDiscos_ListaEditarDiscos.addItemDecoration(erv);
        recyclerView_ListaDiscos_ListaEditarDiscos.setHasFixedSize(true);

        AdaptadorRecyclerView adaptador = new AdaptadorRecyclerView(listaDiscos_ListaEditarDiscos, this);
        recyclerView_ListaDiscos_ListaEditarDiscos.setAdapter(adaptador);

        recyclerView_ListaDiscos_ListaEditarDiscos.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {

            GestureDetector gestureDetector = new GestureDetector(ListaEditarDiscos.this, new GestureDetector.SimpleOnGestureListener() {


                @Override
                public boolean onSingleTapUp(@NonNull MotionEvent e) {
                    return true;
                }


            });

            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                View tocado = recyclerView_ListaDiscos_ListaEditarDiscos.findChildViewUnder(e.getX(), e.getY());

                if(tocado!=null && gestureDetector.onTouchEvent(e)){

                    int posicion = recyclerView_ListaDiscos_ListaEditarDiscos.getChildAdapterPosition(tocado);

                    Intent intent = new Intent(ListaEditarDiscos.this, EditarDiscos.class);
                    intent.putExtra("id", id_Usuario);
                    intent.putExtra("id_disco", String.valueOf(modelo.getIDDisco(ListaEditarDiscos.this, listaDiscos_ListaEditarDiscos.get(posicion).getDisco())));
                    intent.putExtra("nombre_disco", listaDiscos_ListaEditarDiscos.get(posicion).getDisco());
                    intent.putExtra("artista", listaDiscos_ListaEditarDiscos.get(posicion).getArtista());
                    startActivity(intent);
                    finish();

                }
                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ListaEditarDiscos.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }
}