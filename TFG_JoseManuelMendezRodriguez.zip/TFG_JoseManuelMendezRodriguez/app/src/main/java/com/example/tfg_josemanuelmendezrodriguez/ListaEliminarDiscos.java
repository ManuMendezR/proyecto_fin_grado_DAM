package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;

import java.util.List;

public class ListaEliminarDiscos extends AppCompatActivity {


    ImageButton imgBtn_Flecha_Toolbar_ListaEliminarDiscos;
    RecyclerView recyclerView_ListaDiscos_ListaEliminarDiscos;
    List<ListaDiscos> listaDiscos_ListaEliminarDiscos;
    Toolbar toolbar_EliminarDiscos;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_eliminar_discos);

        imgBtn_Flecha_Toolbar_ListaEliminarDiscos = findViewById(R.id.imgBtn_Flecha_Toolbar_ListaEliminar_Disco);
        recyclerView_ListaDiscos_ListaEliminarDiscos = findViewById(R.id.recyclerView_ListaDiscos_ListaEliminarDiscos);
        toolbar_EliminarDiscos = findViewById(R.id.toolbar_ListaEliminar_Disco);
        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");

        imgBtn_Flecha_Toolbar_ListaEliminarDiscos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ListaEliminarDiscos.this, PantallaPrincipal.class);
                intent.putExtra("id",id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        listaDiscos_ListaEliminarDiscos = modelo.getListaDiscos(ListaEliminarDiscos.this);
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL);
        recyclerView_ListaDiscos_ListaEliminarDiscos.setLayoutManager(staggeredGridLayoutManager);
        EspaciadoRecyclerView erv = new EspaciadoRecyclerView(10);
        recyclerView_ListaDiscos_ListaEliminarDiscos.addItemDecoration(erv);
        recyclerView_ListaDiscos_ListaEliminarDiscos.setHasFixedSize(true);

        AdaptadorRecyclerView adaptador = new AdaptadorRecyclerView(listaDiscos_ListaEliminarDiscos, this);
        recyclerView_ListaDiscos_ListaEliminarDiscos.setAdapter(adaptador);

        recyclerView_ListaDiscos_ListaEliminarDiscos.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {

            GestureDetector gestureDetector = new GestureDetector(ListaEliminarDiscos.this, new GestureDetector.SimpleOnGestureListener() {


                @Override
                public boolean onSingleTapUp(@NonNull MotionEvent e) {
                    return true;
                }


            });

            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                View tocado = recyclerView_ListaDiscos_ListaEliminarDiscos.findChildViewUnder(e.getX(), e.getY());

                if(tocado!=null && gestureDetector.onTouchEvent(e)){

                    int posicion = recyclerView_ListaDiscos_ListaEliminarDiscos.getChildAdapterPosition(tocado);

                    AlertDialog.Builder alerta = new AlertDialog.Builder(ListaEliminarDiscos.this);
                    alerta.setTitle("Eliminar disco");
                    alerta.setMessage("¿Quiere eliminar este disco? Esta acción es permanente y no se puede deshacer");
                    alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            AlertDialog.Builder alerta = new AlertDialog.Builder(ListaEliminarDiscos.this);
                            alerta.setTitle("Eliminar disco");
                            alerta.setMessage("¿Está completamente seguro?");
                            alerta.setPositiveButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {



                                }
                            });
                            alerta.setNegativeButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    int id_disco = modelo.getIDDisco(ListaEliminarDiscos.this, listaDiscos_ListaEliminarDiscos.get(posicion).getDisco());

                                    modelo.eliminaVentas(ListaEliminarDiscos.this, id_disco);
                                    modelo.eliminaValoraciones(ListaEliminarDiscos.this, id_disco);
                                    modelo.eliminaDisco(ListaEliminarDiscos.this, id_disco);

                                    Intent intent = new Intent(ListaEliminarDiscos.this, PantallaPrincipal.class);
                                    intent.putExtra("id",id_Usuario);
                                    startActivity(intent);
                                    finish();

                                }
                            });

                            AlertDialog dialogo = alerta.create();
                            dialogo.show();

                        }
                    });
                    alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog dialogo = alerta.create();
                    dialogo.show();

                }
                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ListaEliminarDiscos.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }
}