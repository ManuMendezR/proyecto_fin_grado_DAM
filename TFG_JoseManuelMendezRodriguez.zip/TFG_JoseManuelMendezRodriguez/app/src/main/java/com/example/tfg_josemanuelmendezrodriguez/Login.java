package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public class Login extends AppCompatActivity {

    Button btn_Registro_Login;
    Button btn_IniciarSesion_Login;
    EditText ed_NombreUsuario_Login;
    EditText ed_Contrasena_Login;
    TextInputLayout textInput_NombreUsuario_Login;
    TextInputLayout textInput_Contrasena_Login;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        textInput_NombreUsuario_Login = findViewById(R.id.textInput_NombreUsuario_Login);
        textInput_Contrasena_Login = findViewById(R.id.textInput_Contrasena_Login);
        Modelo modelo = new Modelo();

        if(modelo.getIDUsuario(Login.this, "admin") == -1){

            Usuario usuario = new Usuario();
            usuario.setNombreUsuario("admin");
            usuario.setContrasena("admin");
            usuario.setEmail("admin@gmail.com");
            usuario.setTipo("admin");
            modelo.insertaUsuario(Login.this, usuario);
        }

        ed_NombreUsuario_Login = findViewById(R.id.textEdit_NombreUsuario_Login);
        ed_Contrasena_Login = findViewById(R.id.textEdit_Contrasena_Login);
        btn_IniciarSesion_Login = findViewById(R.id.btn_IniciarSesion_Login);
        btn_Registro_Login = findViewById(R.id.btn_Registrarse_Login);

        btn_IniciarSesion_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!ed_NombreUsuario_Login.getText().toString().isEmpty() && !ed_Contrasena_Login.getText().toString().isEmpty()){

                    if(modelo.getIDUsuario(Login.this, ed_NombreUsuario_Login.getText().toString().trim())!=-1){

                        textInput_NombreUsuario_Login.setHelperText("");

                        if(modelo.getContrasenaUsuario(Login.this, ed_NombreUsuario_Login.getText().toString().trim()).equals(ed_Contrasena_Login.getText().toString())){

                            textInput_Contrasena_Login.setHelperText("");

                            Intent intent = new Intent(Login.this, PantallaPrincipal.class);
                            intent.putExtra("id", String.valueOf(modelo.getIDUsuario(Login.this, ed_NombreUsuario_Login.getText().toString().trim())));
                            startActivity(intent);
                            finish();

                        }else{

                            textInput_Contrasena_Login.setHelperText("La contraseña no es correcta");
                            textInput_Contrasena_Login.setHelperTextColor(getResources().getColorStateList(R.color.red));

                            textInput_NombreUsuario_Login.setHelperText("");
                        }

                    }else{

                        textInput_NombreUsuario_Login.setHelperText("El usuario introducido no existe");
                        textInput_NombreUsuario_Login.setHelperTextColor(getResources().getColorStateList(R.color.red));

                        textInput_Contrasena_Login.setHelperText("");

                    }
                }else{

                    Toast.makeText(Login.this, "Por favor, rellene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_Registro_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Login.this, Registro.class);
                startActivity(intent);
                finish();
            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(Login.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }


}