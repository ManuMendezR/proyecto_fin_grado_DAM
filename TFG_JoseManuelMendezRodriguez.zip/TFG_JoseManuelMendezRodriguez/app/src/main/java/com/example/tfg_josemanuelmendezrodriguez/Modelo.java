package com.example.tfg_josemanuelmendezrodriguez;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase encargada de realizar operaciones en la base de datos
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class Modelo {

    /**
     * Método que se conecta a la base de datos
     * @param context
     * @return
     */
    public SQLiteDatabase conectar(Context context){

        //Este objeto referencia a la clase que hemos creado anteriormente, la que extendia de sql y creaba la tabla.
        ConexionSQLite conexion = new ConexionSQLite(context, "BBDD_TFG_9",null,1);
        SQLiteDatabase db = conexion.getWritableDatabase();
        return db;
    }

    /**
     * Método que inserta nuevos usuarios en la base de datos
     * @param contexto
     * @param usuario
     * @return
     */
    int insertaUsuario(Context contexto, Usuario usuario){

        int resultado = 0;
        String sql = "INSERT INTO usuarios(nombre_usuario,email,contrasena, tipo) VALUES ('"+usuario.getNombreUsuario()+"', '"+usuario.getEmail()+"', '"+usuario.getContrasena()+"', '"+usuario.getTipo()+"')";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que actualiza los datos de un usuario
     * @param contexto
     * @param usuario
     * @param id_Usuario
     * @return
     */
    int actualizarUsuario(Context contexto, Usuario usuario, String id_Usuario){

        int resultado = 0;
        String sql = "UPDATE usuarios SET nombre_usuario = '"+usuario.getNombreUsuario()+"', email = '"+usuario.getEmail()+"', contrasena = '"+usuario.getContrasena()+"' WHERE id = '"+id_Usuario+"'";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que otorga privilegios de administrador a un usuario
     * @param contexto
     * @param id_Usuario
     * @return
     */
    int promocionarAdmin(Context contexto, String id_Usuario){

        int resultado = 0;
        String sql = "UPDATE usuarios SET tipo = 'admin' WHERE id = '"+id_Usuario+"'";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que obtiene la ID de un usuario
     * @param contexto
     * @param nombreUsuarioBuscar
     * @return
     */
    int getIDUsuario(Context contexto, String nombreUsuarioBuscar){

        int resultado = -1;
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreUsuarioBuscar};

        Cursor miCursor = db.rawQuery("SELECT id FROM usuarios WHERE nombre_usuario = ?",array);

        if(miCursor.moveToFirst()){

            do{

                int id = miCursor.getInt(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;

    }

    /**
     * Método que obtiene la contraseña de un usuario
     * @param contexto
     * @param nombreUsuarioBuscar
     * @return
     */
    String getContrasenaUsuario(Context contexto, String nombreUsuarioBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreUsuarioBuscar};

        Cursor miCursor = db.rawQuery("SELECT contrasena FROM usuarios WHERE nombre_usuario = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que obtiene el nombre de un usuario
     * @param contexto
     * @param idUsuarioBuscar
     * @return
     */
    String getNombreUsuario(Context contexto, String idUsuarioBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {idUsuarioBuscar};

        Cursor miCursor = db.rawQuery("SELECT nombre_usuario FROM usuarios WHERE id = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que obtiene el email de un usuario
     * @param contexto
     * @param idUsuarioBuscar
     * @return
     */
    String getEmailUsuario(Context contexto, String idUsuarioBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {idUsuarioBuscar};

        Cursor miCursor = db.rawQuery("SELECT email FROM usuarios WHERE id = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que obtiene el tipo de un usuario
     * @param contexto
     * @param idUsuarioBuscar
     * @return
     */
    String getTipoUsuario(Context contexto, String idUsuarioBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {idUsuarioBuscar};

        Cursor miCursor = db.rawQuery("SELECT tipo FROM usuarios WHERE id = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que elimina un usuario de la base de datos
     * @param contexto
     * @param id_usuario
     * @return
     */
    int eliminaUsuario(Context contexto, String id_usuario){

        int resultado = 0;
        String sql = "DELETE FROM usuarios WHERE id = "+id_usuario+" ";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que inserta un nuevo disco en la base de datos
     * @param contexto
     * @param disco
     * @return
     */
    int insertaDisco(Context contexto, Disco disco){

        int resultado = 0;
        String sql = "INSERT INTO discos(nombre_disco,artista,genero, num_canciones, precio, stock, puntuacion_total) VALUES ('"+disco.getNombreDisco()+"', '"+disco.getArtista()+"', '"+disco.getGenero()+"', '"+disco.getNum_canciones()+"', '"+disco.getPrecio()+"', '"+disco.getStock()+"', '"+disco.getPuntuacion()+"')";
        SQLiteDatabase db = this.conectar(contexto);

        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que obtiene la ID de un disco
     * @param contexto
     * @param nombreDiscoBuscar
     * @return
     */
    int getIDDisco(Context contexto, String nombreDiscoBuscar){

        int resultado = -1;
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT id FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                int id = miCursor.getInt(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;

    }

    /**
     * Método que obtiene una lista con todos los nombres de disco y de artista de la base de datos
     * @param contexto
     * @return
     */
    List<ListaDiscos> getListaDiscos(Context contexto){

        List<ListaDiscos> resultado = new ArrayList<>();
        SQLiteDatabase db = this.conectar(contexto);

        Cursor miCursor = db.rawQuery("SELECT nombre_disco, artista FROM discos", null);

        if(miCursor.moveToFirst()){

            do{

                String nombre_disco = miCursor.getString(0);
                String artista = miCursor.getString(1);
                ListaDiscos aux = new ListaDiscos(nombre_disco, artista);
                resultado.add(aux);

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que obtiene el género de un disco
     * @param contexto
     * @param nombreDiscoBuscar
     * @return
     */
    String getGeneroDisco(Context contexto, String nombreDiscoBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT genero FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que obtiene el número de canciones de un disco
     * @param contexto
     * @param nombreDiscoBuscar
     * @return
     */
    String getNumCancionesDisco(Context contexto, String nombreDiscoBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT num_canciones FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que obtiene el precio de un disco
     * @param contexto
     * @param nombreDiscoBuscar
     * @return
     */
    String getPrecioDisco(Context contexto, String nombreDiscoBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT precio FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que obtiene el stock de un disco
     * @param contexto
     * @param nombreDiscoBuscar
     * @return
     */
    String getStockDisco(Context contexto, String nombreDiscoBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT stock FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que obtiene la puntuación total de un disco
     * @param contexto
     * @param nombreDiscoBuscar
     * @return
     */
    String getPuntuacionTotalDisco(Context contexto, String nombreDiscoBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT puntuacion_total FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que actualiza los datos de un disco
     * @param contexto
     * @param disco
     * @param id_Disco
     * @return
     */
    int actualizarDisco(Context contexto, Disco disco, String id_Disco){

        int resultado = 0;
        String sql = "UPDATE discos SET nombre_disco = '"+disco.getNombreDisco()+"', artista = '"+disco.getArtista()+"', genero = '"+disco.getGenero()+"', num_canciones = '"+disco.getNum_canciones()+"', precio = '"+disco.getPrecio()+"', stock = '"+disco.getStock()+"' WHERE id = '"+id_Disco+"'";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que actualiza la puntuación total de un disco
     * @param contexto
     * @param id_Disco
     * @param puntuacion_total
     * @return
     */
    int actualizarPuntuacionTotal(Context contexto, String id_Disco, double puntuacion_total){

        int resultado = 0;
        String sql = "UPDATE discos SET puntuacion_total = "+puntuacion_total+" WHERE id = '"+id_Disco+"'";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que actualiza el stock de un disco
     * @param contexto
     * @param id_Disco
     * @param stock
     * @return
     */
    int actualizarStock(Context contexto, String id_Disco, int stock){

        int resultado = 0;
        String sql = "UPDATE discos SET stock = "+stock+" WHERE id = '"+id_Disco+"'";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Modelo que elimina un disco de la base de datos
     * @param contexto
     * @param id_disco
     * @return
     */
    int eliminaDisco(Context contexto, int id_disco){

        int resultado = 0;
        String sql = "DELETE FROM discos WHERE id = "+id_disco+" ";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que inserta una nueva valoración en la base de datos
     * @param contexto
     * @param valoracion
     * @return
     */
    int insertaValoracion(Context contexto, Valoracion valoracion){

        int resultado = 0;
        String sql = "INSERT INTO valoraciones(id_Usuario,id_Disco, puntuacion) VALUES ("+valoracion.getId_Usuario()+", "+valoracion.getId_Disco()+", "+valoracion.getPuntuacion()+")";
        SQLiteDatabase db = this.conectar(contexto);

        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que elimina valoraciones de la base de datos
     * @param contexto
     * @param id_disco
     * @return
     */
    int eliminaValoraciones(Context contexto, int id_disco){

        int resultado = 0;
        String sql = "DELETE FROM valoraciones WHERE id_Disco = "+id_disco+" ";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que establece a null la referencia a un usuario borrado de la base de datos de una valoracion
     * @param contexto
     * @param id_usuario
     * @return
     */
    int nulificarUsuarioValoracion(Context contexto, String id_usuario){

        int resultado = 0;
        String sql = "UPDATE valoraciones SET id_Usuario = null WHERE id_Usuario = "+id_usuario+" ";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que comprueba si un usuario ha validado previamente un disco determinado
     * @param contexto
     * @param id_Usuario
     * @param id_Disco
     * @return
     */
    int comprobarUsuarioValidacion(Context contexto, String id_Usuario, String id_Disco){

        int resultado = -1;
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {id_Disco, id_Usuario};

        Cursor miCursor = db.rawQuery("SELECT id FROM valoraciones WHERE id_disco = ? AND id_usuario = ?",array);

        if(miCursor.moveToFirst()){

            do{

                int id = miCursor.getInt(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que obtiene la suma de todas las valoraciones de un disco
     * @param contexto
     * @param id_Disco
     * @return
     */
    double getSumaPuntuacion(Context contexto, String id_Disco){

        double resultado = -1;
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {id_Disco};

        Cursor miCursor = db.rawQuery("SELECT SUM(puntuacion) FROM valoraciones WHERE id_disco = ? ",array);

        if(miCursor.moveToFirst()){

            do{

                double id = miCursor.getInt(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que obtiene la cantidad de valoraciones de un disco
     * @param contexto
     * @param id_Disco
     * @return
     */
    int getCountPuntuaciones(Context contexto, String id_Disco){

        int resultado = -1;
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {id_Disco};

        Cursor miCursor = db.rawQuery("SELECT COUNT(*) FROM valoraciones WHERE id_disco = ? ",array);

        if(miCursor.moveToFirst()){

            do{

                int id = miCursor.getInt(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    /**
     * Método que inserta una nueva venta en la base de datos
     * @param contexto
     * @param venta
     * @return
     */
    int insertaVenta(Context contexto, Venta venta){

        int resultado = 0;
        String sql = "INSERT INTO ventas(id_Usuario,id_Disco, fecha) VALUES ("+venta.getId_Usuario()+", "+venta.getId_Disco()+", '"+venta.getFecha()+"')";
        SQLiteDatabase db = this.conectar(contexto);

        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Método que elimina una venta de la base de datos
     * @param contexto
     * @param id_disco
     * @return
     */
    int eliminaVentas(Context contexto, int id_disco){

        int resultado = 0;
        String sql = "DELETE FROM ventas WHERE id_Disco = "+id_disco+" ";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    /**
     * Métod que establece a null el valor de un usuario eliminado de la base de datos de una venta
     * @param contexto
     * @param id_usuario
     * @return
     */
    int nulificarUsuarioVenta(Context contexto, String id_usuario){

        int resultado = 0;
        String sql = "UPDATE ventas SET id_Usuario = null WHERE id_Usuario = "+id_usuario+" ";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }


}