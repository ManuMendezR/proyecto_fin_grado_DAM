package com.example.tfg_josemanuelmendezrodriguez;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

//Esta clase se encarga de realizar operaciones en la base de datos
public class Modelo {

    //Este método se conecta a la base de datos
    public SQLiteDatabase conectar(Context context){

        //Este objeto referencia a la clase que hemos creado anteriormente, la que extendia de sql y creaba la tabla.
        ConexionSQLite conexion = new ConexionSQLite(context, "BBDD_TFG_2",null,1);
        SQLiteDatabase db = conexion.getWritableDatabase();
        return db;
    }

    //BLOQUE DE MÉTODOS DE LOS USUARIOS
    //----------------------------------------------------------------------------------------------
    //Este método inserta nuevos usuarios en la base de datos
    int insertaUsuario(Context contexto, Usuario usuario){

        int resultado = 0;
        String sql = "INSERT INTO usuarios(nombre_usuario,email,contrasena, tipo) VALUES ('"+usuario.getNombreUsuario()+"', '"+usuario.getEmail()+"', '"+usuario.getContrasena()+"', '"+usuario.getTipo()+"')";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    int actualizarUsuario(Context contexto, Usuario usuario, String id_Usuario){

        int resultado = 0;
        String sql = "UPDATE usuarios SET nombre_usuario = '"+usuario.getNombreUsuario()+"', email = '"+usuario.getEmail()+"', contrasena = '"+usuario.getContrasena()+"' WHERE id = '"+id_Usuario+"'";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    int promocionarAdmin(Context contexto, String id_Usuario){

        int resultado = 0;
        String sql = "UPDATE usuarios SET tipo = 'admin' WHERE id = '"+id_Usuario+"'";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    int getIDUsuario(Context contexto, String nombreUsuarioBuscar){

        int resultado = -1;
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreUsuarioBuscar};

        Cursor miCursor = db.rawQuery("SELECT id FROM usuarios WHERE nombre_usuario = ?",array);

        if(miCursor.moveToFirst()){

            do{

                int id = miCursor.getInt(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;

    }

    String getContrasenaUsuario(Context contexto, String nombreUsuarioBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreUsuarioBuscar};

        Cursor miCursor = db.rawQuery("SELECT contrasena FROM usuarios WHERE nombre_usuario = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    String getNombreUsuario(Context contexto, String idUsuarioBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {idUsuarioBuscar};

        Cursor miCursor = db.rawQuery("SELECT nombre_usuario FROM usuarios WHERE id = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    String getEmailUsuario(Context contexto, String idUsuarioBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {idUsuarioBuscar};

        Cursor miCursor = db.rawQuery("SELECT email FROM usuarios WHERE id = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    String getTipoUsuario(Context contexto, String idUsuarioBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {idUsuarioBuscar};

        Cursor miCursor = db.rawQuery("SELECT tipo FROM usuarios WHERE id = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    //----------------------------------------------------------------------------------------------

    //BLOQUE DE MÉTODOS DE LOS DISCOS
    //----------------------------------------------------------------------------------------------

    int insertaDisco(Context contexto, Disco disco){

        int resultado = 0;
        String sql = "INSERT INTO discos(nombre_disco,artista,genero, num_canciones, precio, stock) VALUES ('"+disco.getNombreDisco()+"', '"+disco.getArtista()+"', '"+disco.getGenero()+"', '"+disco.getNum_canciones()+"', '"+disco.getPrecio()+"', '"+disco.getStock()+"')";
        SQLiteDatabase db = this.conectar(contexto);

        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }

    int getIDDisco(Context contexto, String nombreDiscoBuscar){

        int resultado = -1;
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT id FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                int id = miCursor.getInt(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;

    }

    List<ListaDiscos> getListaDiscos(Context contexto){

        List<ListaDiscos> resultado = new ArrayList<>();
        SQLiteDatabase db = this.conectar(contexto);

        Cursor miCursor = db.rawQuery("SELECT nombre_disco, artista FROM discos", null);

        if(miCursor.moveToFirst()){

            do{

                String nombre_disco = miCursor.getString(0);
                String artista = miCursor.getString(1);
                ListaDiscos aux = new ListaDiscos(nombre_disco, artista);
                resultado.add(aux);

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    String getGeneroDisco(Context contexto, String nombreDiscoBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT genero FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    String getNumCancionesDisco(Context contexto, String nombreDiscoBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT num_canciones FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    String getPrecioDisco(Context contexto, String nombreDiscoBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT precio FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    String getStockDisco(Context contexto, String nombreDiscoBuscar){

        String resultado = "";
        SQLiteDatabase db = this.conectar(contexto);
        String array[] = {nombreDiscoBuscar};

        Cursor miCursor = db.rawQuery("SELECT stock FROM discos WHERE nombre_disco = ?",array);

        if(miCursor.moveToFirst()){

            do{

                String id = miCursor.getString(0);
                resultado = id;

            }while(miCursor.moveToNext());
        }
        miCursor.close();

        return resultado;
    }

    int actualizarDisco(Context contexto, Disco disco, String id_Disco){

        int resultado = 0;
        String sql = "UPDATE discos SET nombre_disco = '"+disco.getNombreDisco()+"', artista = '"+disco.getArtista()+"', genero = '"+disco.getGenero()+"', num_canciones = '"+disco.getNum_canciones()+"', precio = '"+disco.getPrecio()+"', stock = '"+disco.getStock()+"' WHERE id = '"+id_Disco+"'";
        SQLiteDatabase db = this.conectar(contexto);


        try{
            db.execSQL(sql);
            resultado = 1;
        }catch(Exception e){


        }

        return resultado;

    }





}