package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

/**
 * Clase asociada a la pantalla en la que los usuarios pueden modificar los datos de su perfil
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class ModificarPerfil extends AppCompatActivity {

    EditText ed_NombreUsuario_ModificarPerfil; /** EditText utilizado para introducir el nombre de usuario*/
    EditText ed_Email_ModificarPerfil; /** EditText utilizado para introducir el email*/
    EditText ed_Contrasena_ModificarPerfil; /** EditText utilizado para introducir la contraseña */
    EditText ed_ConfirmarContrasena_ModificarPerfil; /** EditText utilizado para introducir la confirmación de la contraseña*/
    TextInputLayout textInput_NombreUsuario_ModificarPerfil; /**TextInput utilizado para introducir el nombre de usuario */
    TextInputLayout textInput_Email_ModificarPerfil; /**TextInput utilizado para introducir el email */
    TextInputLayout textInput_Contrasena_ModificarPerfil; /**TextInput utilizado para introducir la contraseña */
    TextInputLayout textInput_ConfirmarContrasena_ModificarPerfil; /**TextInput utilizado para introducir la confirmación de contraseña */
    Button btn_ActualizarDatos_ModificarPerfil; /** Botón para modificar los datos del usuario con los nuevos introducidos*/
    ImageButton imgBtn_Flecha_Toolbar_ModificarPerfil; /** ImageButton que permite al usuario volver a la pantalla anterior*/
    Toolbar toolbar_ModificarPerfil; /** Variable que hace referencia a la toolbar*/
    /**
     * Método onCreate de la clase
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     *
     */
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_perfil);

        /** Asocio las variables con sus respectivas ids*/
        ed_NombreUsuario_ModificarPerfil = findViewById(R.id.textEdit_NombreUsuario_ModificarPerfil);
        ed_Email_ModificarPerfil = findViewById(R.id.textEdit_Email_ModificarPerfil);
        ed_Contrasena_ModificarPerfil = findViewById(R.id.textEdit_Contrasena_ModificarPerfil);
        ed_ConfirmarContrasena_ModificarPerfil = findViewById(R.id.textEdit_ConfirmarContrasena_ModificarPerfil);
        textInput_NombreUsuario_ModificarPerfil = findViewById(R.id.textInput_NombreUsuario_ModificarPerfil);
        textInput_Email_ModificarPerfil = findViewById(R.id.textInput_Email_ModificarPerfil);
        textInput_Contrasena_ModificarPerfil = findViewById(R.id.textInput_Contrasena_ModificarPerfil);
        textInput_ConfirmarContrasena_ModificarPerfil = findViewById(R.id.textInput_ConfirmarContrasena_ModificarPerfil);
        btn_ActualizarDatos_ModificarPerfil = findViewById(R.id.btn_ActualizarDatos_ModificarPerfil);
        imgBtn_Flecha_Toolbar_ModificarPerfil = findViewById(R.id.imgBtn_Flecha_Toolbar_AdministracionVerCodigo);
        toolbar_ModificarPerfil = findViewById(R.id.toolbar_ModificarPerfil);
        setSupportActionBar(toolbar_ModificarPerfil);

        /** Creo un objeto modelo y recibo los datos del intent*/
        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");
        String nombre_Usuario = modelo.getNombreUsuario(ModificarPerfil.this, id_Usuario);
        String email_Usuario = modelo.getEmailUsuario(ModificarPerfil.this, id_Usuario);
        String contrasena_Usuario = modelo.getContrasenaUsuario(ModificarPerfil.this, nombre_Usuario);

        /** Establezco los datos del usuario en los EditText para mas facilidad en la actualización*/
        ed_NombreUsuario_ModificarPerfil.setText(nombre_Usuario);
        ed_Email_ModificarPerfil.setText(email_Usuario);
        ed_Contrasena_ModificarPerfil.setText(contrasena_Usuario);
        ed_ConfirmarContrasena_ModificarPerfil.setText(contrasena_Usuario);
        String nombre_Inicial = ed_NombreUsuario_ModificarPerfil.getText().toString();

        /**
         * Escuchador del botón "Modificar Perfil" que modificará los datos del usuario cambiandolos por los nuevos siempre y cuando
         * se cumplan todas las validaciones de los distintos campos
         */
        btn_ActualizarDatos_ModificarPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!ed_NombreUsuario_ModificarPerfil.getText().toString().isEmpty() && !ed_Email_ModificarPerfil.getText().toString().isEmpty()
                && !ed_Contrasena_ModificarPerfil.getText().toString().isEmpty() && !ed_ConfirmarContrasena_ModificarPerfil.getText().toString().isEmpty()){

                    if(ed_NombreUsuario_ModificarPerfil.getText().toString().trim().length()>4 && ed_NombreUsuario_ModificarPerfil.getText().toString().trim().length()<15){

                        textInput_NombreUsuario_ModificarPerfil.setHelperText("");

                        if((ed_Email_ModificarPerfil.getText().toString().toLowerCase().trim().contains("@gmail") || ed_Email_ModificarPerfil.getText().toString().toLowerCase().trim().contains("@hotmail"))
                                && (ed_Email_ModificarPerfil.getText().toString().toLowerCase().trim().endsWith(".es") || ed_Email_ModificarPerfil.getText().toString().toLowerCase().trim().endsWith(".com"))
                                && (!ed_Email_ModificarPerfil.getText().toString().toLowerCase().trim().startsWith("@gmail") && !ed_Email_ModificarPerfil.getText().toString().toLowerCase().trim().startsWith("@hotmail"))){

                            textInput_Email_ModificarPerfil.setHelperText("");

                            if(ed_Contrasena_ModificarPerfil.getText().toString().length()>5){

                                textInput_Contrasena_ModificarPerfil.setHelperText("");

                                if(ed_Contrasena_ModificarPerfil.getText().toString().trim().equals(ed_ConfirmarContrasena_ModificarPerfil.getText().toString().trim())){

                                    textInput_ConfirmarContrasena_ModificarPerfil.setHelperText("");

                                    Modelo modelo = new Modelo();
                                    Usuario usuario = new Usuario();
                                    usuario.setNombreUsuario(ed_NombreUsuario_ModificarPerfil.getText().toString().trim());
                                    usuario.setContrasena(ed_Contrasena_ModificarPerfil.getText().toString().trim());
                                    usuario.setEmail(ed_Email_ModificarPerfil.getText().toString().trim());

                                    if(modelo.getIDUsuario(ModificarPerfil.this, ed_NombreUsuario_ModificarPerfil.getText().toString().trim()) == -1 || ed_NombreUsuario_ModificarPerfil.getText().toString().equals(nombre_Inicial)){


                                        modelo.actualizarUsuario(ModificarPerfil.this, usuario, id_Usuario);


                                        AlertDialog.Builder alerta = new AlertDialog.Builder(ModificarPerfil.this);
                                        alerta.setTitle("Exito");
                                        alerta.setMessage("Los datos se han actualizado correctamente");
                                        alerta.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                                Intent intent = new Intent(ModificarPerfil.this, Perfil.class);
                                                intent.putExtra("id", id_Usuario);
                                                startActivity(intent);
                                                finish();

                                            }
                                        });

                                        AlertDialog dialogo = alerta.create();
                                        dialogo.show();


                                    }else{

                                        Toast.makeText(ModificarPerfil.this, "Ya existe un usuario con ese nombre", Toast.LENGTH_SHORT).show();
                                    }


                                }else{

                                    textInput_ConfirmarContrasena_ModificarPerfil.setHelperText("Las contraseñas no coinciden");
                                    textInput_ConfirmarContrasena_ModificarPerfil.setHelperTextColor(getResources().getColorStateList(R.color.red));

                                    textInput_NombreUsuario_ModificarPerfil.setHelperText("");
                                    textInput_Email_ModificarPerfil.setHelperText("");
                                    textInput_Contrasena_ModificarPerfil.setHelperText("");
                                }

                            }else{

                                textInput_Contrasena_ModificarPerfil.setHelperText("La contraseña debe tener 6 caracteres como mínimo");
                                textInput_Contrasena_ModificarPerfil.setHelperTextColor(getResources().getColorStateList(R.color.red));

                                textInput_NombreUsuario_ModificarPerfil.setHelperText("");
                                textInput_Email_ModificarPerfil.setHelperText("");
                                textInput_ConfirmarContrasena_ModificarPerfil.setHelperText("");
                            }

                        }else{

                            textInput_Email_ModificarPerfil.setHelperText("Introduzca un correo válido");
                            textInput_Email_ModificarPerfil.setHelperTextColor(getResources().getColorStateList(R.color.red));

                            textInput_NombreUsuario_ModificarPerfil.setHelperText("");
                            textInput_Contrasena_ModificarPerfil.setHelperText("");
                            textInput_ConfirmarContrasena_ModificarPerfil.setHelperText("");
                        }

                    }else{

                        textInput_NombreUsuario_ModificarPerfil.setHelperText("El nombre de usuario debe tener entre 4 y 15 caracteres");
                        textInput_NombreUsuario_ModificarPerfil.setHelperTextColor(getResources().getColorStateList(R.color.red));

                        textInput_Email_ModificarPerfil.setHelperText("");
                        textInput_Contrasena_ModificarPerfil.setHelperText("");
                        textInput_ConfirmarContrasena_ModificarPerfil.setHelperText("");


                    }

                }else{

                    Toast.makeText(ModificarPerfil.this, "Por favor, rellene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /**
         * Escuchador del Imagebutton que permitirá al usuario volver a la pantalla anterior
         */
        imgBtn_Flecha_Toolbar_ModificarPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ModificarPerfil.this, Perfil.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        /**
         * Método que preguntará al usuario si quiere cerrar la aplicación al pulsar el botón "Atras" del teléfono.
         */
        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ModificarPerfil.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });

    }
}