package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;
/**
 * Clase asociada a la pantalla principal, la cual muestra una lista con los discos de la BBDD
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class PantallaPrincipal extends AppCompatActivity {

    RecyclerView recyclerView_ListaDiscos_PantallaPrincipal; /** RecyclerView en el cual se va a ver la lista con los distintos discos*/
    List<ListaDiscos> listaDiscos_PantallaPrincipal; /** Lista con los discos de la BBDD*/
    FloatingActionButton floatingActionButton_Menu_PantallaPrincipal; /** Floating button que despliega el menú para acceder a las operaciones de administrador*/
    FloatingActionButton floatingActionButton_Anadir_PantallaPrincipal; /** Floating button que lleva al usuario a la pantalla para añadir nuevos discos a la BBDD*/
    FloatingActionButton floatingActionButton_Editar_PantallaPrincipal; /** Floating button que lleva al usuario a la pantalla para editar discos de la BBDD*/
    FloatingActionButton floatingActionButton_Eliminar_PantallaPrincipal; /** Floating button que lleva al usuario a la pantalla para eliminar discos de la BBDD*/
    Animation girarDerecha; /** Animacion girar a la derecha*/
    Animation girarIzquierda; /** Animacion girar a la izquierda*/
    Animation aparecer; /** Animacion aparecer*/
    Animation desaparecer; /** Animacion desaparecer*/
    Toolbar toolbar_PantallaPrincipal; /** Variable que representa la toolbar*/
    boolean isPulsado = false; /** Variable que permite saber si el menú está desplegado o no*/
    String id_Usuario_aux; /** Variable auxiliar de la id del usuario*/
    /**
     * Método onCreate de la clase
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     *
     */
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_principal);

        /** Asocio las variables a sus respectivas id*/
        floatingActionButton_Menu_PantallaPrincipal = findViewById(R.id.floatingActionButton_Menu_PantallaPrincipal);
        floatingActionButton_Anadir_PantallaPrincipal = findViewById(R.id.floatingActionButton_Anadir_PantallaPrincipal);
        floatingActionButton_Editar_PantallaPrincipal = findViewById(R.id.floatingActionButton_Editar_PantallaPrincipal);
        floatingActionButton_Eliminar_PantallaPrincipal = findViewById(R.id.floatingActionButton_Eliminar_PantallaPrincipal);
        toolbar_PantallaPrincipal = findViewById(R.id.toolbar_PantallaPrincipal);
        setSupportActionBar(toolbar_PantallaPrincipal);
        //getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar_PantallaPrincipal.setOverflowIcon(getResources().getDrawable(R.drawable.user_icon));

        /** Creo un objeto de tipo modelo y obtengo los datos del intent*/
        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");
        id_Usuario_aux = id_Usuario;

        /** En este bloque de código se prepara el recyclerview con los datos de los discos y un adaptador*/
        listaDiscos_PantallaPrincipal = modelo.getListaDiscos(PantallaPrincipal.this);
        recyclerView_ListaDiscos_PantallaPrincipal = findViewById(R.id.recyclerView_ListaDiscos_PantallaPrincipal);
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL);
        recyclerView_ListaDiscos_PantallaPrincipal.setLayoutManager(staggeredGridLayoutManager);
        EspaciadoRecyclerView erv = new EspaciadoRecyclerView(10);
        recyclerView_ListaDiscos_PantallaPrincipal.addItemDecoration(erv);
        recyclerView_ListaDiscos_PantallaPrincipal.setHasFixedSize(true);

        AdaptadorRecyclerView adaptador = new AdaptadorRecyclerView(listaDiscos_PantallaPrincipal, this);
        recyclerView_ListaDiscos_PantallaPrincipal.setAdapter(adaptador);

        /**
         * Escuchador del recyclerView que permite seleccionar el disco que se va a editar
         */
        recyclerView_ListaDiscos_PantallaPrincipal.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {

            GestureDetector gestureDetector = new GestureDetector(PantallaPrincipal.this, new GestureDetector.SimpleOnGestureListener() {


                @Override
                public boolean onSingleTapUp(@NonNull MotionEvent e) {
                    return true;
                }


            });

            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                View tocado = recyclerView_ListaDiscos_PantallaPrincipal.findChildViewUnder(e.getX(), e.getY());

                if(tocado!=null && gestureDetector.onTouchEvent(e)){

                    int posicion = recyclerView_ListaDiscos_PantallaPrincipal.getChildAdapterPosition(tocado);

                    Intent intent = new Intent(PantallaPrincipal.this, DetallesDisco.class);
                    intent.putExtra("id", id_Usuario);
                    intent.putExtra("id_disco", String.valueOf(modelo.getIDDisco(PantallaPrincipal.this, listaDiscos_PantallaPrincipal.get(posicion).getDisco())));
                    intent.putExtra("nombre_disco", listaDiscos_PantallaPrincipal.get(posicion).getDisco());
                    intent.putExtra("artista", listaDiscos_PantallaPrincipal.get(posicion).getArtista());
                    startActivity(intent);
                    finish();

                }
                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });

        /** Compruebo que el usuario activo es administrador, en cuyo caso, se hace visible el botón flotante que despliega el menú*/
        if(modelo.getTipoUsuario(PantallaPrincipal.this, id_Usuario).equals("admin")){

            floatingActionButton_Menu_PantallaPrincipal.setVisibility(View.VISIBLE);
        }

        /** Aplico las distintas animaciones a las variables correspondientes*/
        girarDerecha = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.girar_45_derecha);
        girarDerecha.setFillAfter(true);
        girarIzquierda = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.girar_45_izquierda);
        girarIzquierda.setFillAfter(true);
        aparecer = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.combinada_aparecer);
        aparecer.setFillAfter(true);
        desaparecer = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.combinada_desaparecer);

        /**
         * Escuchador del botón flotante del menú que ejecutará unas animaciones u otras para hacer aparecer u ocultar el resto de botones flotantes
         */
        floatingActionButton_Menu_PantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(isPulsado==false){

                    floatingActionButton_Menu_PantallaPrincipal.startAnimation(girarDerecha);
                    isPulsado = true;
                    floatingActionButton_Anadir_PantallaPrincipal.startAnimation(aparecer);
                    floatingActionButton_Editar_PantallaPrincipal.startAnimation(aparecer);
                    floatingActionButton_Eliminar_PantallaPrincipal.startAnimation(aparecer);

                }else if(isPulsado == true){

                    floatingActionButton_Menu_PantallaPrincipal.startAnimation(girarIzquierda);
                    isPulsado = false;
                    floatingActionButton_Anadir_PantallaPrincipal.startAnimation(desaparecer);
                    floatingActionButton_Editar_PantallaPrincipal.startAnimation(desaparecer);
                    floatingActionButton_Eliminar_PantallaPrincipal.startAnimation(desaparecer);

                }
            }
        });

        /**
         *  Escuchador del botón flotante "Añadir" que llevará al usuario a la pantalla para añadir un nuevo disco a la BBDD
         */
        floatingActionButton_Anadir_PantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(PantallaPrincipal.this, AnadirDiscos.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        /**
         * Escuchador del botón flotante "Editar" que llevará al usuario a la pantalla para editar un disco de la BBDD
         */
        floatingActionButton_Editar_PantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(PantallaPrincipal.this, ListaEditarDiscos.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        /**
         * Escuchador del botón flotante "Eliminar" que llevará al usuario a la pantalla para eliminar discos de la BBDD
         */
        floatingActionButton_Eliminar_PantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(PantallaPrincipal.this, ListaEliminarDiscos.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        /**
         * Método que preguntará al usuario si quiere salir de la aplicación al pulsar el botón "Atras" del teléfono
         */
        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(PantallaPrincipal.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });

    }

    /**
     * Método que infla el menú de la toolbar para poder acceder a la pantalla del perfil y cerrar sesión
     * @param menu The options menu in which you place your items.
     *
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    /**
     * Método que da funcionalidad al menú del botón del perfil de la toolbar
     * @param item The menu item that was selected.
     *
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        if(item.getItemId() == R.id.item_Perfil){
            
            Intent intent = new Intent(PantallaPrincipal.this, Perfil.class);
            intent.putExtra("id", id_Usuario_aux);
            startActivity(intent);
            finish();
        }

        if(item.getItemId() == R.id.item_CerrarSesion){

            AlertDialog.Builder alerta = new AlertDialog.Builder(PantallaPrincipal.this);
            alerta.setTitle("Cerrar sesión");
            alerta.setMessage("¿Seguro que quiere cerrar la sesión?");
            alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    Intent intent = new Intent(PantallaPrincipal.this, Login.class);
                    startActivity(intent);
                    finish();

                }
            });
            alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {


                }
            });

            AlertDialog dialogo = alerta.create();
            dialogo.show();

        }

        return super.onContextItemSelected(item);
    }
}