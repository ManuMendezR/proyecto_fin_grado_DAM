package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class PantallaPrincipal extends AppCompatActivity {

    RecyclerView recyclerView_ListaDiscos_PantallaPrincipal;
    List<ListaDiscos> listaDiscos_PantallaPrincipal;
    FloatingActionButton floatingActionButton_Menu_PantallaPrincipal;
    FloatingActionButton floatingActionButton_Anadir_PantallaPrincipal;
    FloatingActionButton floatingActionButton_Editar_PantallaPrincipal;
    FloatingActionButton floatingActionButton_Eliminar_PantallaPrincipal;
    Animation girarDerecha;
    Animation girarIzquierda;
    Animation aparecer;
    Animation desaparecer;
    Toolbar toolbar_PantallaPrincipal;
    boolean isPulsado = false;
    String id_Usuario_aux;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_principal);

        Modelo modelo = new Modelo();
        floatingActionButton_Menu_PantallaPrincipal = findViewById(R.id.floatingActionButton_Menu_PantallaPrincipal);
        floatingActionButton_Anadir_PantallaPrincipal = findViewById(R.id.floatingActionButton_Anadir_PantallaPrincipal);
        floatingActionButton_Editar_PantallaPrincipal = findViewById(R.id.floatingActionButton_Editar_PantallaPrincipal);
        floatingActionButton_Eliminar_PantallaPrincipal = findViewById(R.id.floatingActionButton_Eliminar_PantallaPrincipal);
        toolbar_PantallaPrincipal = findViewById(R.id.toolbar_PantallaPrincipal);

        setSupportActionBar(toolbar_PantallaPrincipal);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar_PantallaPrincipal.setOverflowIcon(getResources().getDrawable(R.drawable.user_icon));

        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");
        id_Usuario_aux = id_Usuario;


        listaDiscos_PantallaPrincipal = modelo.getListaDiscos(PantallaPrincipal.this);


        recyclerView_ListaDiscos_PantallaPrincipal = findViewById(R.id.recyclerView_ListaDiscos_PantallaPrincipal);
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL);
        recyclerView_ListaDiscos_PantallaPrincipal.setLayoutManager(staggeredGridLayoutManager);
        EspaciadoRecyclerView erv = new EspaciadoRecyclerView(10);
        recyclerView_ListaDiscos_PantallaPrincipal.addItemDecoration(erv);
        recyclerView_ListaDiscos_PantallaPrincipal.setHasFixedSize(true);

        AdaptadorRecyclerView adaptador = new AdaptadorRecyclerView(listaDiscos_PantallaPrincipal, this);
        recyclerView_ListaDiscos_PantallaPrincipal.setAdapter(adaptador);

        recyclerView_ListaDiscos_PantallaPrincipal.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {

            GestureDetector gestureDetector = new GestureDetector(PantallaPrincipal.this, new GestureDetector.SimpleOnGestureListener() {


                @Override
                public boolean onSingleTapUp(@NonNull MotionEvent e) {
                    return true;
                }


            });

            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                View tocado = recyclerView_ListaDiscos_PantallaPrincipal.findChildViewUnder(e.getX(), e.getY());

                if(tocado!=null && gestureDetector.onTouchEvent(e)){

                    int posicion = recyclerView_ListaDiscos_PantallaPrincipal.getChildAdapterPosition(tocado);

                    Intent intent = new Intent(PantallaPrincipal.this, DetallesDisco.class);
                    intent.putExtra("id", id_Usuario);
                    intent.putExtra("id_disco", String.valueOf(modelo.getIDDisco(PantallaPrincipal.this, listaDiscos_PantallaPrincipal.get(posicion).getDisco())));
                    intent.putExtra("nombre_disco", listaDiscos_PantallaPrincipal.get(posicion).getDisco());
                    intent.putExtra("artista", listaDiscos_PantallaPrincipal.get(posicion).getArtista());
                    startActivity(intent);
                    finish();

                }
                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });

        if(modelo.getTipoUsuario(PantallaPrincipal.this, id_Usuario).equals("admin")){

            floatingActionButton_Menu_PantallaPrincipal.setVisibility(View.VISIBLE);
        }

        girarDerecha = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.girar_45_derecha);
        girarDerecha.setFillAfter(true);
        girarIzquierda = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.girar_45_izquierda);
        girarIzquierda.setFillAfter(true);
        aparecer = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.combinada_aparecer);
        aparecer.setFillAfter(true);
        desaparecer = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.combinada_desaparecer);

        floatingActionButton_Menu_PantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(isPulsado==false){

                    floatingActionButton_Menu_PantallaPrincipal.startAnimation(girarDerecha);
                    isPulsado = true;
                    floatingActionButton_Anadir_PantallaPrincipal.startAnimation(aparecer);
                    floatingActionButton_Editar_PantallaPrincipal.startAnimation(aparecer);
                    floatingActionButton_Eliminar_PantallaPrincipal.startAnimation(aparecer);

                }else if(isPulsado == true){

                    floatingActionButton_Menu_PantallaPrincipal.startAnimation(girarIzquierda);
                    isPulsado = false;
                    floatingActionButton_Anadir_PantallaPrincipal.startAnimation(desaparecer);
                    floatingActionButton_Editar_PantallaPrincipal.startAnimation(desaparecer);
                    floatingActionButton_Eliminar_PantallaPrincipal.startAnimation(desaparecer);

                }
            }
        });

        floatingActionButton_Anadir_PantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(PantallaPrincipal.this, AnadirDiscos.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        floatingActionButton_Editar_PantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(PantallaPrincipal.this, ListaEditarDiscos.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(PantallaPrincipal.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });

    }

    //Este método infla el menu para que sea visible en la toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    //Este método le da funcionalidad a las distintas opciones del menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        if(item.getItemId() == R.id.item_Perfil){
            
            Intent intent = new Intent(PantallaPrincipal.this, Perfil.class);
            intent.putExtra("id", id_Usuario_aux);
            startActivity(intent);
            finish();
        }

        if(item.getItemId() == R.id.item_CerrarSesion){

            AlertDialog.Builder alerta = new AlertDialog.Builder(PantallaPrincipal.this);
            alerta.setTitle("Cerrar sesión");
            alerta.setMessage("¿Seguro que quiere cerrar la sesión?");
            alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    Intent intent = new Intent(PantallaPrincipal.this, Login.class);
                    startActivity(intent);
                    finish();

                }
            });
            alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {


                }
            });

            AlertDialog dialogo = alerta.create();
            dialogo.show();

        }

        return super.onContextItemSelected(item);
    }
}