package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class PantallaPrincipal extends AppCompatActivity {

    ImageButton imgBtn_Perfil_PantallaPrincipal;
    RecyclerView recyclerView_ListaDiscos_PantallaPrincipal;
    List<ListaDiscos> listaDiscos;
    FloatingActionButton floatingActionButton_Menu_PantallaPrincipal;
    FloatingActionButton floatingActionButton_Anadir_PantallaPrincipal;
    FloatingActionButton floatingActionButton_Editar_PantallaPrincipal;
    FloatingActionButton floatingActionButton_Eliminar_PantallaPrincipal;
    Animation girarDerecha;
    Animation girarIzquierda;
    Animation aparecer;
    Animation desaparecer;
    boolean isPulsado = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_principal);

        Modelo modelo = new Modelo();
        floatingActionButton_Menu_PantallaPrincipal = findViewById(R.id.floatingActionButton_Menu_PantallaPrincipal);
        floatingActionButton_Anadir_PantallaPrincipal = findViewById(R.id.floatingActionButton_Anadir_PantallaPrincipal);
        floatingActionButton_Editar_PantallaPrincipal = findViewById(R.id.floatingActionButton_Editar_PantallaPrincipal);
        floatingActionButton_Eliminar_PantallaPrincipal = findViewById(R.id.floatingActionButton_Eliminar_PantallaPrincipal);
        imgBtn_Perfil_PantallaPrincipal = findViewById(R.id.imgBtn_Perfil_PantallaPrincipal);
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");


        imgBtn_Perfil_PantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(PantallaPrincipal.this, Perfil.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        listaDiscos = modelo.getListaDiscos(PantallaPrincipal.this);


        recyclerView_ListaDiscos_PantallaPrincipal = findViewById(R.id.recyclerView_ListaDiscos_PantallaPrincipal);
/*
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);*/

        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL);
        recyclerView_ListaDiscos_PantallaPrincipal.setLayoutManager(staggeredGridLayoutManager);
        EspaciadoRecyclerView erv = new EspaciadoRecyclerView(10);
        recyclerView_ListaDiscos_PantallaPrincipal.addItemDecoration(erv);
        recyclerView_ListaDiscos_PantallaPrincipal.setHasFixedSize(true);

        AdaptadorRecyclerView adaptador = new AdaptadorRecyclerView(listaDiscos, this);
        recyclerView_ListaDiscos_PantallaPrincipal.setAdapter(adaptador);

        recyclerView_ListaDiscos_PantallaPrincipal.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {

            GestureDetector gestureDetector = new GestureDetector(PantallaPrincipal.this, new GestureDetector.SimpleOnGestureListener() {


                @Override
                public boolean onSingleTapUp(@NonNull MotionEvent e) {
                    return true;
                }


            });

            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                View tocado = recyclerView_ListaDiscos_PantallaPrincipal.findChildViewUnder(e.getX(), e.getY());

                if(tocado!=null && gestureDetector.onTouchEvent(e)){

                    int posicion = recyclerView_ListaDiscos_PantallaPrincipal.getChildAdapterPosition(tocado);

                    Toast.makeText(PantallaPrincipal.this, "El disco es: "+listaDiscos.get(posicion).getDisco(), Toast.LENGTH_SHORT).show();
                }
                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });

        if(modelo.getTipoUsuario(PantallaPrincipal.this, id_Usuario).equals("admin")){

            floatingActionButton_Menu_PantallaPrincipal.setVisibility(View.VISIBLE);
        }

        girarDerecha = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.girar_45_derecha);
        girarDerecha.setFillAfter(true);
        girarIzquierda = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.girar_45_izquierda);
        girarIzquierda.setFillAfter(true);
        aparecer = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.combinada_aparecer);
        aparecer.setFillAfter(true);
        desaparecer = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.combinada_desaparecer);

        floatingActionButton_Menu_PantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(isPulsado==false){

                    floatingActionButton_Menu_PantallaPrincipal.startAnimation(girarDerecha);
                    isPulsado = true;
                    floatingActionButton_Anadir_PantallaPrincipal.startAnimation(aparecer);
                    floatingActionButton_Editar_PantallaPrincipal.startAnimation(aparecer);
                    floatingActionButton_Eliminar_PantallaPrincipal.startAnimation(aparecer);

                }else if(isPulsado == true){

                    floatingActionButton_Menu_PantallaPrincipal.startAnimation(girarIzquierda);
                    isPulsado = false;
                    floatingActionButton_Anadir_PantallaPrincipal.startAnimation(desaparecer);
                    floatingActionButton_Editar_PantallaPrincipal.startAnimation(desaparecer);
                    floatingActionButton_Eliminar_PantallaPrincipal.startAnimation(desaparecer);

                }
            }
        });

        floatingActionButton_Anadir_PantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(PantallaPrincipal.this, AnadirDiscos.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(PantallaPrincipal.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });

    }
}