package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class Perfil extends AppCompatActivity {

    TextView textView_NombrePerfil_Perfil;
    Button btn_ModificarPerfil_Perfil;
    Button btn_Administracion_Perfil;
    Button btn_EliminarCuenta_Perfil;
    ImageButton imgBtn_CerrarSesion_Perfil;
    Toolbar toolbar;
    ImageButton imgBtn_flecha_Toolbar_Perfil;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        btn_ModificarPerfil_Perfil = findViewById(R.id.btn_ModificarPerfil_Perfil);
        btn_Administracion_Perfil = findViewById(R.id.btn_Administracion_Perfil);
        btn_EliminarCuenta_Perfil = findViewById(R.id.btn_EliminarCuenta_Perfil);
        toolbar = findViewById(R.id.toolbar_AdministracionVerCodigo);
        imgBtn_flecha_Toolbar_Perfil = findViewById(R.id.imgBtn_Flecha_Toolbar_Perfil);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");
        String nombre_Usuario = modelo.getNombreUsuario(Perfil.this, id_Usuario);
        textView_NombrePerfil_Perfil = findViewById(R.id.textView_Nombre_Perfil);
        textView_NombrePerfil_Perfil.setText(nombre_Usuario);

        btn_ModificarPerfil_Perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(id_Usuario.equals("1")){

                    Toast.makeText(Perfil.this, "El administrador original no puede ser modificado", Toast.LENGTH_SHORT).show();

                }else{

                    Intent intent = new Intent(Perfil.this, ModificarPerfil.class);
                    intent.putExtra("id", id_Usuario);
                    startActivity(intent);
                    finish();

                }

            }
        });

        btn_Administracion_Perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(modelo.getTipoUsuario(Perfil.this, id_Usuario).equals("admin")){

                    Intent intent = new Intent(Perfil.this, AdministracionVerCodigo.class);
                    intent.putExtra("id", id_Usuario);
                    startActivity(intent);
                    finish();

                }else{

                    Intent intent = new Intent(Perfil.this, AdministracionPromocionarAdmin.class);
                    intent.putExtra("id", id_Usuario);
                    startActivity(intent);
                    finish();
                }
            }
        });

        btn_EliminarCuenta_Perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(id_Usuario.equals("1")){

                    Toast.makeText(Perfil.this, "El administrador original no puede ser borrado", Toast.LENGTH_SHORT).show();

                }else{

                    AlertDialog.Builder alerta = new AlertDialog.Builder(Perfil.this);
                    alerta.setTitle("Eliminar cuenta");
                    alerta.setMessage("¿Quiere eliminar este usuario? Esta acción es permanente y no se puede deshacer");
                    alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            AlertDialog.Builder alerta = new AlertDialog.Builder(Perfil.this);
                            alerta.setTitle("Eliminar cuenta");
                            alerta.setMessage("¿Está completamente seguro?");
                            alerta.setPositiveButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {



                                }
                            });
                            alerta.setNegativeButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    modelo.nulificarUsuarioValoracion(Perfil.this, id_Usuario);
                                    modelo.nulificarUsuarioVenta(Perfil.this, id_Usuario);
                                    modelo.eliminaUsuario(Perfil.this, id_Usuario);
                                    Intent intent = new Intent(Perfil.this, Login.class);
                                    startActivity(intent);
                                    finish();

                                }
                            });

                            AlertDialog dialogo = alerta.create();
                            dialogo.show();

                        }
                    });
                    alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog dialogo = alerta.create();
                    dialogo.show();

                }

                }

        });


        imgBtn_flecha_Toolbar_Perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Perfil.this, PantallaPrincipal.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(Perfil.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }
}