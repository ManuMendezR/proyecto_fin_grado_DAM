package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Clase asociada a la pantalla en la que el usuario puede gestionar su perfil
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class Perfil extends AppCompatActivity {

    TextView textView_NombrePerfil_Perfil; /** TextView que contiene el nombre del usuario*/
    Button btn_ModificarPerfil_Perfil; /** Botón que llevará al usuario a la pantalla para modificar los datos de su perfil*/
    Button btn_Administracion_Perfil; /** Botón que llevará al usuario a la pantalla de administración*/
    Button btn_EliminarCuenta_Perfil; /** Botón que permitirá al usuario eliminar su cuenta*/
    Toolbar toolbar; /** Variable que representa la toolbar*/
    ImageButton imgBtn_flecha_Toolbar_Perfil; /** ImageButton que permite al usuario volver a la pantalla anterior*/
    /**
     * Método onCreate de la clase
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     *
     */
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        /** Asocio las variables a sus respectivas id*/
        btn_ModificarPerfil_Perfil = findViewById(R.id.btn_ModificarPerfil_Perfil);
        btn_Administracion_Perfil = findViewById(R.id.btn_Administracion_Perfil);
        btn_EliminarCuenta_Perfil = findViewById(R.id.btn_EliminarCuenta_Perfil);
        textView_NombrePerfil_Perfil = findViewById(R.id.textView_Nombre_Perfil);
        toolbar = findViewById(R.id.toolbar_Perfil);
        imgBtn_flecha_Toolbar_Perfil = findViewById(R.id.imgBtn_Flecha_Toolbar_Perfil);
        setSupportActionBar(toolbar);
        //getSupportActionBar().setDisplayShowTitleEnabled(false);
        /** Creo un objeto de tipo modelo y obtengo los datos del intent*/
        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");
        String nombre_Usuario = modelo.getNombreUsuario(Perfil.this, id_Usuario);
        /** Establezco el nombre del usuario en el textView*/
        textView_NombrePerfil_Perfil.setText(nombre_Usuario);

        /**
         * Escuchador del botón "Modificar perfil" que llevará al usuario a la pantalla en la que poder modificar su perfil
         */
        btn_ModificarPerfil_Perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(id_Usuario.equals("1")){

                    Toast.makeText(Perfil.this, "El administrador original no puede ser modificado", Toast.LENGTH_SHORT).show();

                }else{

                    Intent intent = new Intent(Perfil.this, ModificarPerfil.class);
                    intent.putExtra("id", id_Usuario);
                    startActivity(intent);
                    finish();

                }

            }
        });

        /**
         * Escuchador del botón "Administracion" que llevará al usuario a la pantalla para obtener privilegios de administrador
         * o ver el código de la administración en función de si es un usuario general o con privilegios de administrador, respectivamente
         */
        btn_Administracion_Perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(modelo.getTipoUsuario(Perfil.this, id_Usuario).equals("admin")){

                    Intent intent = new Intent(Perfil.this, AdministracionVerCodigo.class);
                    intent.putExtra("id", id_Usuario);
                    startActivity(intent);
                    finish();

                }else{

                    Intent intent = new Intent(Perfil.this, AdministracionPromocionarAdmin.class);
                    intent.putExtra("id", id_Usuario);
                    startActivity(intent);
                    finish();
                }
            }
        });

        /**
         * Escuchador del botón "Eliminar cuenta" el cual permitirá eliminar al usuario los datos de su cuenta de la BBDD
         */
        btn_EliminarCuenta_Perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(id_Usuario.equals("1")){

                    Toast.makeText(Perfil.this, "El administrador original no puede ser borrado", Toast.LENGTH_SHORT).show();

                }else{

                    AlertDialog.Builder alerta = new AlertDialog.Builder(Perfil.this);
                    alerta.setTitle("Eliminar cuenta");
                    alerta.setMessage("¿Quiere eliminar este usuario? Esta acción es permanente y no se puede deshacer");
                    alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            AlertDialog.Builder alerta = new AlertDialog.Builder(Perfil.this);
                            alerta.setTitle("Eliminar cuenta");
                            alerta.setMessage("¿Está completamente seguro?");
                            alerta.setPositiveButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {



                                }
                            });
                            alerta.setNegativeButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    modelo.nulificarUsuarioValoracion(Perfil.this, id_Usuario);
                                    modelo.nulificarUsuarioVenta(Perfil.this, id_Usuario);
                                    modelo.eliminaUsuario(Perfil.this, id_Usuario);
                                    Intent intent = new Intent(Perfil.this, Login.class);
                                    startActivity(intent);
                                    finish();

                                }
                            });

                            AlertDialog dialogo = alerta.create();
                            dialogo.show();

                        }
                    });
                    alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog dialogo = alerta.create();
                    dialogo.show();

                }

                }

        });

        /**
         * Escuchador del ImageButton que permite al usuario volver a la pantalla anterior
         */
        imgBtn_flecha_Toolbar_Perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Perfil.this, PantallaPrincipal.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();
            }
        });

        /**
         * Método que pregunta al usuario si quiere salir de la aplicación al pulsar el botón "Atras" del teléfono
         */
        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(Perfil.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }
}