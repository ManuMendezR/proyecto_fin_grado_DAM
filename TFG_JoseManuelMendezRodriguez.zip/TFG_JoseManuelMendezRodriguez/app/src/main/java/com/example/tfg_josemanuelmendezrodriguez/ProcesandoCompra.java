package com.example.tfg_josemanuelmendezrodriguez;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;

public class ProcesandoCompra extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_procesando_compra);

        Modelo modelo = new Modelo();
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");

        int max = 5000;
        //Le doy el valor maximo a la barra de progreso

        //Creo este método(un contador) al que se le pasa el tiempo que va a durar en milisegundos y el intervalo en el que hace las acciones
        new CountDownTimer(max,10) {
            @Override
            public void onTick(long l) {


            }

            @Override//Cuando termine el contador, realizará lo que haya dentro de este método.
            public void onFinish() {

                Intent intent = new Intent(ProcesandoCompra.this, PantallaPrincipal.class);
                intent.putExtra("id", id_Usuario);
                startActivity(intent);
                finish();

            }
        }.start();//Inicio el temporizador
    }
}