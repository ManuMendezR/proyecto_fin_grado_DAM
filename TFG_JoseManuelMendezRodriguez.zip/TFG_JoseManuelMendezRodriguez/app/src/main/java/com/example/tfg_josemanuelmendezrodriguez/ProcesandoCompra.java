package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;

/**
 * Clase asociada a la pantalla que aparece cuando un usuario compra un disco
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class ProcesandoCompra extends AppCompatActivity {

    /**
     * Método onCreate de la clase
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     *
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_procesando_compra);

        /** Obtengo los datos del intent*/
        Bundle extras = getIntent().getExtras();
        String id_Usuario = extras.getString("id");


        /**
         * En el siguiente bloque de código, se ejecuta un temporizador de 5 segundos, y al terminar, muestra un mensaje
         * que informa al usuario de que la compra se ha realizado exitósamente y al pulsar el botón "Aceptar"
         * le devolverá a la pantalla principal
         */
        int max = 5000;
        new CountDownTimer(max,10) {
            @Override
            public void onTick(long l) {


            }

            @Override
            public void onFinish() {

                AlertDialog.Builder alerta = new AlertDialog.Builder(ProcesandoCompra.this);
                alerta.setTitle("Exito");
                alerta.setMessage("Compra realizada exitosamente");
                alerta.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Intent intent = new Intent(ProcesandoCompra.this, PantallaPrincipal.class);
                        intent.putExtra("id", id_Usuario);
                        startActivity(intent);
                        finish();

                    }
                });

                alerta.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {

                        Intent intent = new Intent(ProcesandoCompra.this, PantallaPrincipal.class);
                        intent.putExtra("id", id_Usuario);
                        startActivity(intent);
                        finish();
                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();

            }
        }.start();

        /**
         * Método que bloquea la funcionalidad del botón "Atras" del teléfono
         */
        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {

            }
        });
    }
}