package com.example.tfg_josemanuelmendezrodriguez;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

import java.util.*;

public class Registro extends AppCompatActivity {

    Button btn_Registro_Registro;
    EditText ed_NombreUsuario_Registro;
    EditText ed_Email_Registro;
    EditText ed_Contrasena_Registro;
    EditText ed_ConfirmarContrasena_Registro;
    TextInputLayout textInput_NombreUsuario_Registro;
    TextInputLayout textInput_Email_Registro;
    TextInputLayout textInput_Contrasena_Registro;
    TextInputLayout textInput_ConfirmarContrasena_Registro;
    ImageButton imgBtn_FlechaVolver_Registro;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        textInput_NombreUsuario_Registro = findViewById(R.id.textInput_NombreUsuario_Registro);
        textInput_Email_Registro = findViewById(R.id.textInput_Email_Registro);
        textInput_Contrasena_Registro = findViewById(R.id.textInput_Contrasena_Registro);
        textInput_ConfirmarContrasena_Registro = findViewById(R.id.textInput_ConfirmarContrasena_Registro);
        ed_NombreUsuario_Registro = findViewById(R.id.textEdit_NombreUsuario_Registro);
        ed_Email_Registro = findViewById(R.id.textEdit_Email_Registro);
        ed_Contrasena_Registro = findViewById(R.id.textEdit_Contrasena_Registro);
        ed_ConfirmarContrasena_Registro = findViewById(R.id.textEdit_ConfirmarContrasena_Registro);
        imgBtn_FlechaVolver_Registro = findViewById(R.id.imgBtn_FlechaVolver_Registro);

        btn_Registro_Registro = findViewById(R.id.btn_Registrarse_Registro);
        btn_Registro_Registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!ed_NombreUsuario_Registro.getText().toString().trim().isEmpty() && !ed_Email_Registro.getText().toString().trim().isEmpty()
                        && !ed_Contrasena_Registro.getText().toString().trim().isEmpty() && !ed_ConfirmarContrasena_Registro.getText().toString().trim().isEmpty()){

                    if(ed_NombreUsuario_Registro.getText().toString().trim().length()>4){

                        textInput_NombreUsuario_Registro.setHelperText("");

                        if((ed_Email_Registro.getText().toString().toLowerCase().trim().contains("@gmail") || ed_Email_Registro.getText().toString().toLowerCase().trim().contains("@hotmail"))
                                && (ed_Email_Registro.getText().toString().toLowerCase().trim().endsWith(".es") || ed_Email_Registro.getText().toString().toLowerCase().trim().endsWith(".com"))
                                && (!ed_Email_Registro.getText().toString().toLowerCase().trim().startsWith("@gmail") && !ed_Email_Registro.getText().toString().toLowerCase().trim().startsWith("@hotmail"))){

                            textInput_Email_Registro.setHelperText("");

                            if(ed_Contrasena_Registro.getText().toString().trim().length()>5){

                                textInput_Contrasena_Registro.setHelperText("");

                                if(ed_Contrasena_Registro.getText().toString().trim().equals(ed_ConfirmarContrasena_Registro.getText().toString().trim())){

                                    textInput_ConfirmarContrasena_Registro.setHelperText("");
                                    Modelo modelo = new Modelo();
                                    Usuario usuario = new Usuario();
                                    usuario.setNombreUsuario(ed_NombreUsuario_Registro.getText().toString().trim());
                                    usuario.setContrasena(ed_Contrasena_Registro.getText().toString().trim());
                                    usuario.setEmail(ed_Email_Registro.getText().toString().trim());
                                    usuario.setTipo("usuario");

                                    if(modelo.getIDUsuario(Registro.this, ed_NombreUsuario_Registro.getText().toString().trim()) == -1){

                                        Toast.makeText(Registro.this, "Todo bien por aqui jefe", Toast.LENGTH_SHORT).show();
                                        modelo.insertaUsuario(Registro.this, usuario);

                                        //En el siguiente bloque de código creo un dialogo que informa de que el registro se ha realizado correctamente
                                        AlertDialog.Builder alerta = new AlertDialog.Builder(Registro.this);
                                        alerta.setTitle("Exito");
                                        alerta.setMessage("El registro se realizó exitosamente");
                                        alerta.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                                Intent intent = new Intent(Registro.this, Login.class);
                                                startActivity(intent);
                                                finish();

                                            }
                                        });

                                        AlertDialog dialogo = alerta.create();
                                        dialogo.show();


                                    }else{

                                        Toast.makeText(Registro.this, "Ya existe un usuario con ese nombre", Toast.LENGTH_SHORT).show();
                                    }



                                }else{

                                    textInput_ConfirmarContrasena_Registro.setHelperText("Las contraseñas no coinciden");
                                    textInput_ConfirmarContrasena_Registro.setHelperTextColor(getResources().getColorStateList(R.color.red));
                                }

                            }else{

                                textInput_Contrasena_Registro.setHelperText("La contraseña debe tener 6 caracteres como mínimo");
                                textInput_Contrasena_Registro.setHelperTextColor(getResources().getColorStateList(R.color.red));

                            }
                        }else{

                            textInput_Email_Registro.setHelperText("Introduzca un correo válido");
                            textInput_Email_Registro.setHelperTextColor(getResources().getColorStateList(R.color.red));
                        }

                    }else{

                        textInput_NombreUsuario_Registro.setHelperText("El nombre de usuario debe tener mas de 4 caracteres");
                        textInput_NombreUsuario_Registro.setHelperTextColor(getResources().getColorStateList(R.color.red));
                    }
                }else{

                    Toast.makeText(Registro.this, "Por favor, rellene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        imgBtn_FlechaVolver_Registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Registro.this, Login.class);
                startActivity(intent);
                finish();
            }
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AlertDialog.Builder alerta = new AlertDialog.Builder(Registro.this);
                alerta.setTitle("Salir");
                alerta.setMessage("¿Quiere salir de la aplicación?");
                alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                });
                alerta.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog dialogo = alerta.create();
                dialogo.show();
            }
        });
    }
}