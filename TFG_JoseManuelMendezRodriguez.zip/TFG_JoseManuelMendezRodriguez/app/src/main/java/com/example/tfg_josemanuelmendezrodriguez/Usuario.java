package com.example.tfg_josemanuelmendezrodriguez;

/**
 * Clase que representa un objeto de tipo usuario
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class Usuario {


    private String nombreUsuario; /** Variable que representa el nombre del usuario*/

    private String contrasena; /** Variable que representa la contraseña del usuario*/

    private String email; /** Variable que representa el email del usuario*/

    private String tipo; /** Variable que representa el tipo del usuario*/

    /**
     * Método que obtiene el nombre del usuario
     * @return
     */
    public String getNombreUsuario() {
        return nombreUsuario;
    }

    /**
     * Método que establece el nombre del usuario
     * @param nombreUsuario
     */
    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    /**
     * Método que obtiene la contraseña del usuario
     * @return
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Método que establece la contraseña del usuario
     * @param contrasena
     */
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    /**
     * Método que obtiene el email del usuario
     * @return
     */
    public String getEmail() {
        return email;
    }

    /**
     * Método que establece el email del usuario
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Método que obtiene el tipo del usuario
     * @return
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Métodoque establece el tipo del usuario
     * @param tipo
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}