package com.example.tfg_josemanuelmendezrodriguez;

//Esta clase representa a los usuarios de la base de datos
public class Usuario {

    //Esta variable representa el nombre del usuario
    private String nombreUsuario;
    //Esta variable representa la contraseña del usuario
    private String contrasena;
    //Esta variable representa el email del usuario
    private String email;
    //Esta variable representa el tipo de usuario
    private String tipo;

    //Creo los geter y los seter
    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}