package com.example.tfg_josemanuelmendezrodriguez;

public class Valoracion {

    private String id_Usuario;
    private String id_Disco;
    private Double puntuacion;

    public String getId_Usuario() {
        return id_Usuario;
    }

    public void setId_Usuario(String id_Usuario) {
        this.id_Usuario = id_Usuario;
    }

    public String getId_Disco() {
        return id_Disco;
    }

    public void setId_Disco(String id_Disco) {
        this.id_Disco = id_Disco;
    }

    public Double getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(Double puntuacion) {
        this.puntuacion = puntuacion;
    }
}
