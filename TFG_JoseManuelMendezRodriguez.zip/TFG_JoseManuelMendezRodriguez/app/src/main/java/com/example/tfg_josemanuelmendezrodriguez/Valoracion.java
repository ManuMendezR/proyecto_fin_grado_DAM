package com.example.tfg_josemanuelmendezrodriguez;

/**
 * Clase que representa a un objeto de tipo valoración
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class Valoracion {

    private String id_Usuario; /** Variable que representa la id del usuario de la valoración*/
    private String id_Disco; /** Variable que representa la id del disco de la valoración*/
    private Double puntuacion; /** Variable que representa la puntuacion de la valoración*/

    /**
     * Método que obtiene la id del usuario de la valoración
     * @return
     */
    public String getId_Usuario() {
        return id_Usuario;
    }

    /**
     * Método que establece la id del usuario de la valoración
     * @param id_Usuario
     */
    public void setId_Usuario(String id_Usuario) {
        this.id_Usuario = id_Usuario;
    }

    /**
     * Método que obtiene la id del disco de la valoración
     * @return
     */
    public String getId_Disco() {
        return id_Disco;
    }

    /**
     * Método que establece la id del disco de la valoración
     * @param id_Disco
     */
    public void setId_Disco(String id_Disco) {
        this.id_Disco = id_Disco;
    }

    /**
     * Método que obtiene la puntuación de la valoración
     * @return
     */
    public Double getPuntuacion() {
        return puntuacion;
    }

    /**
     * Método que establece la puntuación de la valoración
     * @param puntuacion
     */
    public void setPuntuacion(Double puntuacion) {
        this.puntuacion = puntuacion;
    }
}
