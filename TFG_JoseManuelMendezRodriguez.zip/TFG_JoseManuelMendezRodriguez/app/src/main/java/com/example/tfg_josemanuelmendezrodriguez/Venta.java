package com.example.tfg_josemanuelmendezrodriguez;

/**
 * Clase que representa un objeto de tipo venta
 * @author José Manuel Méndez Rodríguez
 * @version 1.0
 */
public class Venta {

    private String id_Usuario; /** Variable que representa la id del usuario de la venta*/
    private String id_Disco; /** Variable que representa la id del disco de la venta*/
    private String fecha; /** Variable que representa la fecha de la venta*/


    /**
     * Método que obtiene el id del usuario de la venta
     * @return
     */
    public String getId_Usuario() {
        return id_Usuario;
    }

    /**
     * Método que establece el id del usuario de la venta
     * @param id_Usuario
     */
    public void setId_Usuario(String id_Usuario) {
        this.id_Usuario = id_Usuario;
    }

    /**
     * Método que obtiene el id del disco de la venta
     * @return
     */
    public String getId_Disco() {
        return id_Disco;
    }

    /**
     * Método que establece el id del disco de la venta
     * @param id_Disco
     */
    public void setId_Disco(String id_Disco) {
        this.id_Disco = id_Disco;
    }

    /**
     * Método que obtiene la fecha de la venta
     * @return
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * Método que establece la fecha de la venta
     * @param fecha
     */
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}
